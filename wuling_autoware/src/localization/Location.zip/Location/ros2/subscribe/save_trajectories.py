import numpy as np
from scipy.spatial.transform import Rotation as R
import re
import os
import math

def save_odometry_to_txt(slidewindow_graph, data, n, odometry, output_txt_path, timestamp_offset=0):
    """
    将当前位姿估计结果保存到指定的txt文件中，并进行RTK与图像时间戳对齐。

    参数：
    slidewindow_graph: 包含当前位姿的对象，必须具有 current_pose 属性。
    data: 包含图像文件名和其他信息的字典。
    n: 当前图像的索引。
    odometry: 用于保存轨迹数据的列表。
    output_txt_path: 输出的txt文件路径。
    timestamp_offset: RTK与图像时间戳对齐的偏移量（默认值42070.433）。

    返回：
    None
    """
    # 删除旧的txt文件（如果存在）
    if n == 0:
        if os.path.exists(output_txt_path):
            os.remove(output_txt_path)

    # 提取当前位姿中的位置和旋转矩阵
    x, y = slidewindow_graph.current_pose[0, 2], slidewindow_graph.current_pose[1, 2]
    rotation_matrix = slidewindow_graph.current_pose[:2, :2]
    rotation_full = np.eye(3)
    rotation_full[:2, :2] = rotation_matrix
    quaternion = R.from_matrix(rotation_full).as_quat()
    
    # 提取图像时间戳
    match = re.search(r'img_(\d+)\.png', list(data.keys())[n])
    number_str = match.group(1)
    number = int(number_str)
    timestamp = number / 1000  # 转换为秒

    # 将当前位姿和四元数添加到 odometry 列表中
    odometry.append((timestamp, x, y, 0.0, *quaternion))

    # 获取最新的位姿数据
    latest_odometry = odometry[-1]

    # 将位姿估计结果保存到txt文件
    with open(output_txt_path, 'a') as file:
        timestamp, x, y, z, qx, qy, qz, qw = latest_odometry
        timestamp -= timestamp_offset  # RTK与图像时间戳对齐
        line = f"{timestamp:.6f} {-x} {y} {z} {qx} {qy} {qz} {qw}\n"
        file.write(line)

    # print(f"保存最新位姿到 {output_txt_path}")

# 将 yaw 转换为四元数
def yaw_to_quaternion(yaw):
    qx = 0
    qy = 0
    qz = math.sin(yaw / 2)
    qw = math.cos(yaw / 2)
    return qx, qy, qz, qw

def save_trajectory_to_txt(slidewindow_graph, data, output_txt_path, timestamp_offset=0):


    x_coords = slidewindow_graph._slideframes[0]  # x 坐标
    y_coords = slidewindow_graph._slideframes[1]  # y 坐标
    yaws = slidewindow_graph._slideframes[2]      # yaw 角

    with open(output_txt_path, 'w') as file:
        for i in range(len(x_coords)):

            # 提取图像时间戳
            match = re.search(r'img_(\d+)\.png', list(data.keys())[i])
            number_str = match.group(1)
            number = int(number_str)
            timestamp = number / 1000  # 转换为秒
            timestamp -= timestamp_offset  # RTK与图像时间戳对齐
            x = x_coords[i]
            y = y_coords[i]
            z = 0  # 假设 z 坐标为 0
            yaw = yaws[i]
            qx, qy, qz, qw = yaw_to_quaternion(yaw)  # 将 yaw 转为四元数
            file.write(f"{timestamp:.6f} {x} {y} {z} {qx} {qy} {qz} {qw}\n")


def save_frontend_to_txt(slidewindow_graph, data, n, odometry, output_txt_path, timestamp_offset=0):
    # 删除旧的txt文件（如果存在）
    if n == 0:
        if os.path.exists(output_txt_path):
            os.remove(output_txt_path)

    # 提取当前位姿中的位置和旋转矩阵
    # if len(slidewindow_graph._slideframes[0]) == 0:
    #     x, y = 0, 0
    #     rotation_matrix = R.from_euler('z', 0).as_matrix()[:2, :2]
    #     rotation_full = np.eye(3)
    #     rotation_full[:2, :2] = rotation_matrix
    #     quaternion = R.from_matrix(rotation_full).as_quat()
    # else:
    x, y = slidewindow_graph.x, slidewindow_graph.y
    rotation_matrix = R.from_euler('z', slidewindow_graph._yaw).as_matrix()[:2, :2]
    rotation_full = np.eye(3)
    rotation_full[:2, :2] = rotation_matrix
    quaternion = R.from_matrix(rotation_full).as_quat()
    
    # 提取图像时间戳
    match = re.search(r'img_(\d+)\.png', list(data.keys())[n])
    number_str = match.group(1)
    number = int(number_str)
    timestamp = number / 1000  # 转换为秒

    # 将当前位姿和四元数添加到 odometry 列表中
    odometry.append((timestamp, x, y, 0.0, *quaternion))

    # 获取最新的位姿数据
    latest_odometry = odometry[-1]

    # 将位姿估计结果保存到txt文件
    with open(output_txt_path, 'a') as file:
        timestamp, x, y, z, qx, qy, qz, qw = latest_odometry
        timestamp -= timestamp_offset  # RTK与图像时间戳对齐
        line = f"{timestamp:.6f} {x} {y} {z} {qx} {qy} {qz} {qw}\n"
        file.write(line)

    # print(f"保存最新位姿到 {output_txt_path}")

def save_backend_to_txt(slidewindow_graph, data, n, odometry, output_txt_path, timestamp_offset=0):
    # 删除旧的txt文件（如果存在）
    if n == 0:
        if os.path.exists(output_txt_path):
            os.remove(output_txt_path)

    # 提取当前位姿中的位置和旋转矩阵
    if len(slidewindow_graph._slideframes[0]) == 0:
        x, y = 0, 0
        rotation_matrix = R.from_euler('z', 0).as_matrix()[:2, :2]
        rotation_full = np.eye(3)
        rotation_full[:2, :2] = rotation_matrix
        quaternion = R.from_matrix(rotation_full).as_quat()
    else:
        x, y = slidewindow_graph._slideframes[0][-1], slidewindow_graph.current_pose[1][-1]
        rotation_matrix = R.from_euler('z', slidewindow_graph.current_pose[2][-1]).as_matrix()[:2, :2]
        rotation_full = np.eye(3)
        rotation_full[:2, :2] = rotation_matrix
        quaternion = R.from_matrix(rotation_full).as_quat()
    
    # 提取图像时间戳
    match = re.search(r'img_(\d+)\.png', list(data.keys())[n])
    number_str = match.group(1)
    number = int(number_str)
    timestamp = number / 1000  # 转换为秒

    # 将当前位姿和四元数添加到 odometry 列表中
    odometry.append((timestamp, x, y, 0.0, *quaternion))

    # 获取最新的位姿数据
    latest_odometry = odometry[-1]

    # 将位姿估计结果保存到txt文件
    with open(output_txt_path, 'a') as file:
        timestamp, x, y, z, qx, qy, qz, qw = latest_odometry
        timestamp -= timestamp_offset  # RTK与图像时间戳对齐
        line = f"{timestamp:.6f} {x} {y} {z} {qx} {qy} {qz} {qw}\n"
        file.write(line)

    # print(f"保存最新位姿到 {output_txt_path}")

def save_frontend_to_txt_online(slidewindow_graph, n, odometry, output_txt_path, timestamp, timestamp_offset=0):
    # 删除旧的txt文件（如果存在）
    if n == 0:
        if os.path.exists(output_txt_path):
            os.remove(output_txt_path)

    x, y = slidewindow_graph.x, slidewindow_graph.y
    rotation_matrix = R.from_euler('z', slidewindow_graph._yaw).as_matrix()[:2, :2]
    rotation_full = np.eye(3)
    rotation_full[:2, :2] = rotation_matrix
    quaternion = R.from_matrix(rotation_full).as_quat()

    # 将当前位姿和四元数添加到 odometry 列表中
    odometry.append((timestamp, x, y, 0.0, *quaternion))

    # 获取最新的位姿数据
    latest_odometry = odometry[-1]

    # 将位姿估计结果保存到txt文件
    with open(output_txt_path, 'a') as file:
        timestamp, x, y, z, qx, qy, qz, qw = latest_odometry
        timestamp -= timestamp_offset  # RTK与图像时间戳对齐
        line = f"{timestamp:.6f} {x} {y} {z} {qx} {qy} {qz} {qw}\n"
        file.write(line)

def save_backend_to_txt_online(slidewindow_graph, n, odometry, output_txt_path, timestamp, timestamp_offset=0):
    # 删除旧的txt文件（如果存在）
    if n == 0:
        if os.path.exists(output_txt_path):
            os.remove(output_txt_path)

    # 提取当前位姿中的位置和旋转矩阵
    if len(slidewindow_graph._slideframes[0]) == 0:
        x, y = 0, 0
        rotation_matrix = R.from_euler('z', 0).as_matrix()[:2, :2]
        rotation_full = np.eye(3)
        rotation_full[:2, :2] = rotation_matrix
        quaternion = R.from_matrix(rotation_full).as_quat()
    else:
        x, y = slidewindow_graph._slideframes[0][-1], slidewindow_graph.current_pose[1][-1]
        rotation_matrix = R.from_euler('z', slidewindow_graph.current_pose[2][-1]).as_matrix()[:2, :2]
        rotation_full = np.eye(3)
        rotation_full[:2, :2] = rotation_matrix
        quaternion = R.from_matrix(rotation_full).as_quat()
    
    # 将当前位姿和四元数添加到 odometry 列表中
    odometry.append((timestamp, x, y, 0.0, *quaternion))

    # 获取最新的位姿数据
    latest_odometry = odometry[-1]

    # 将位姿估计结果保存到txt文件
    with open(output_txt_path, 'a') as file:
        timestamp, x, y, z, qx, qy, qz, qw = latest_odometry
        timestamp -= timestamp_offset  # RTK与图像时间戳对齐
        line = f"{timestamp:.6f} {x} {y} {z} {qx} {qy} {qz} {qw}\n"
        file.write(line)
