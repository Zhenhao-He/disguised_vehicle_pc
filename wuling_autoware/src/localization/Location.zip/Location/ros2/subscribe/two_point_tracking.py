import numpy as np
from scipy.optimize import least_squares
from scipy.spatial.transform import Rotation as R

def find_common_points(points1, points2):
    """找到两帧之间的公共点，并返回它们的坐标，保证顺序对应"""
    common_ids = set(p[2] for p in points1) & set(p[2] for p in points2)
    points1_common_sorted = [p[:2] for p in sorted(points1, key=lambda x: x[2]) if p[2] in common_ids]
    points2_common_sorted = [p[:2] for p in sorted(points2, key=lambda x: x[2]) if p[2] in common_ids]
    return np.array(points1_common_sorted), np.array(points2_common_sorted)

def estimate_motion_least_squares(points1, points2):
    """
    使用所有点计算帧间的旋转和平移，并取平均值。
    Args:
        points1: 第一帧中的点集 (Nx2 numpy array)
        points2: 第二帧中的点集 (Nx2 numpy array)
    Returns:
        rotation: 平均旋转角度 (弧度)
        translation_vector: 平均平移向量 (2D numpy array)
    """
    if len(points1) < 2:
        return None, None  # 至少需要 2 对点

    # 定义误差函数
    def residual(params):
        theta, tx, ty = params
        R_matrix = np.array([[np.cos(theta), -np.sin(theta)],
                            [np.sin(theta),  np.cos(theta)]])
        t_vector = np.array([tx, ty])

        # 计算变换后的点
        transformed_points = (R_matrix @ points1.T).T + t_vector

        # 计算残差
        residuals = transformed_points - points2
        return residuals.flatten()

    # 初始参数（无旋转、无平移）
    initial_params = [0, 0, 0]

    # 使用最小二乘优化
    result = least_squares(residual, initial_params)

    # 提取优化结果
    theta, tx, ty = result.x
    translation_vector = np.array([tx, ty])

    return theta, translation_vector

def estimate_motion_single_point(points1, points2):
    """
    使用一对匹配点计算帧间的旋转和平移。
    Args:
        points1: 第一帧中的点 (1x3 numpy array, 包括 x, y, yaw)
        points2: 第二帧中的点 (1x3 numpy array, 包括 x, y, yaw)
    Returns:
        theta: 旋转角度 (弧度)
        translation_vector: 平移向量 (2D numpy array)
    """
    # 提取点的位置和朝向
    x1, y1, yaw1 = points1
    x2, y2, yaw2 = points2

    # 计算旋转角度
    theta = yaw2 - yaw1

    # 构造旋转矩阵
    R_matrix = np.array([
        [np.cos(theta), -np.sin(theta)],
        [np.sin(theta),  np.cos(theta)]
    ])

    # 计算平移向量
    translation_vector = np.array([x2, y2]) - R_matrix @ np.array([x1, y1])

    return theta, translation_vector