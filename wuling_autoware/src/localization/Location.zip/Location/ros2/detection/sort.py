import re


def parse_predictions(file_path):
    """
    解析文件中图片名称和预测结果，并返回一个字典。
    """
    with open(file_path, 'r', encoding='utf-8') as file:
        data = file.read()

    # 匹配图片名称和预测结果
    results = re.findall(r'图片名称:\s*(\S+)\n预测结果:\n(\[\[.*?\]\])', data, re.DOTALL)
    parsed_data = {}

    for image_name, predictions in results:
        # 将预测结果字符串转换为列表
        parsed_predictions = eval(predictions)
        parsed_data[image_name] = parsed_predictions

    return parsed_data


def extract_timestamp(image_name):
    """
    从图片名称中提取时间戳（例如 img_1730885422480.png -> 1730885422480）。
    """
    match = re.search(r'\d+', image_name)
    return int(match.group()) if match else None


def sort_by_timestamp(parsed_data):
    """
    根据图片名称中的时间戳对数据进行排序。
    """
    return dict(sorted(parsed_data.items(), key=lambda item: extract_timestamp(item[0])))


def save_to_txt(data, output_path):
    """
    保存数据为原始格式的文本文件。
    """
    with open(output_path, 'w', encoding='utf-8') as txt_file:
        for image_name, predictions in data.items():
            txt_file.write(f"图片名称: {image_name}\n")
            txt_file.write(f"预测结果:\n{predictions}\n\n")


def main():
    # 输入和输出文件路径
    input_file = 'detection/prediction51.txt'  # 替换为实际的输入文件路径
    output_file = 'detection/prediction5.txt'  # 替换为实际的输出文件路径

    # 解析、排序并保存数据
    parsed_data = parse_predictions(input_file)
    sorted_data = sort_by_timestamp(parsed_data)
    save_to_txt(sorted_data, output_file)
    print(f"按时间戳排序后的结果已保存到 {output_file}")


if __name__ == "__main__":
    main()
