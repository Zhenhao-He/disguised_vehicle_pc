#!/bin/bash

evo_ape tum ground_truth/2/utm_trans.txt output/wheel/odometry.txt -p 
