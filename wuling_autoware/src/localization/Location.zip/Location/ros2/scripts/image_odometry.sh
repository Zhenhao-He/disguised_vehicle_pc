#!/bin/bash

gnome-terminal -- bash -c "python3 subscribe/image_odometry.py; exec bash"
sleep 0.5

gnome-terminal -- bash -c "python3 publish/publish.py; exec bash"

