#!/bin/bash

evo_ape tum ground_truth/2/utm_trans.txt output/image/frontend.txt -p
