#!/bin/bash

# 打开第一个终端，运行 wheel_odometry_online.py
gnome-terminal -- bash -c "python3 subscribe/wheel_odometry.py; exec bash"
sleep 0.5

# 打开第五个终端，播放 rosbag 数据
gnome-terminal -- bash -c "ros2 bag play ~/dataset/20241106/2/; exec bash"
