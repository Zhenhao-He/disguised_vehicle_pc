import rclpy
from rclpy.node import Node
from std_msgs.msg import String
import json


class TxtLoaderPublisher(Node):
    def __init__(self, txt_file_path):
        super().__init__('txt_loader_publisher')
        self.publisher = self.create_publisher(String, 'image_predictions', 10)
        self.txt_file_path = txt_file_path
        self.data = self.load_txt_file()
        self.current_index = 0

        # 创建定时器，频率为10Hz
        self.timer = self.create_timer(0.1, self.publish_data)

    def load_txt_file(self):
        """加载txt文件并解析内容"""
        data = []
        with open(self.txt_file_path, 'r') as file:
            lines = file.readlines()

        image_name = None
        marking_points = []

        for line in lines:
            line = line.strip()
            if line.startswith("图片名称:"):
                # 如果有上一个图片名称，则保存当前数据
                if image_name:
                    timestamp = float(image_name.split('_')[1].split('.')[0]) / 1000
                    data.append({
                        "timestamp": timestamp,
                        "marking_points": marking_points
                    })
                # 初始化新的图片数据
                image_name = line.split(":")[1].strip()
                marking_points = []
            elif line.startswith("[["):
                # 将预测结果解析为二维列表
                marking_points = json.loads(line.replace(' ', ''))

        # 保存最后一个图片的内容
        if image_name:
            timestamp = float(image_name.split('_')[1].split('.')[0]) / 1000
            data.append({
                "timestamp": timestamp,
                "marking_points": marking_points
            })

        return data

    def publish_data(self):
        """按顺序发布数据"""
        if self.current_index >= len(self.data):
            self.get_logger().info("All data published.")
            self.destroy_timer(self.timer)
            return

        # 获取当前数据
        current_data = self.data[self.current_index]
        self.current_index += 1

        # 将字典转换为 JSON 字符串
        message = String()
        message.data = json.dumps(current_data)
        # 发布数据
        self.publisher.publish(message)
        # self.get_logger().info(f"Published data: {message.data["timestamp"]}")
        print(f"Published timestamp: {current_data['timestamp']}")


def main(args=None):
    rclpy.init(args=args)

    # 替换为你的txt文件路径
    txt_file_path = './detection/prediction2.txt'

    node = TxtLoaderPublisher(txt_file_path)

    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        node.get_logger().info("Node stopped by user.")
    finally:
        node.destroy_node()
        rclpy.shutdown()


if __name__ == '__main__':
    main()
