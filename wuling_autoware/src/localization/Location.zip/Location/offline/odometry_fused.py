import rclpy
from rclpy.node import Node
from geometry_msgs.msg import PoseStamped
from rclpy.time import Time
import numpy as np
from scipy.linalg import block_diag


class EKFFusionNode(Node):
    def __init__(self):
        super().__init__('ekf_fusion_node')

        # 图像里程计订阅
        self.image_pose_sub = self.create_subscription(
            PoseStamped, '/location/image_odometry', self.image_odometry_callback, 10)

        # 轮速里程计订阅
        self.wheel_pose_sub = self.create_subscription(
            PoseStamped, '/location/wheel_odometry', self.wheel_odometry_callback, 10)

        # 融合结果发布
        self.fused_pose_pub = self.create_publisher(PoseStamped, '/location/fused_pose', 10)

        # 定时器（100Hz频率）
        self.timer = self.create_timer(0.01, self.publish_fused_pose)

        # 状态变量 [x, y, yaw]
        self.state = np.zeros(3)

        # 协方差矩阵 P
        self.P = np.eye(3) * 0.1

        # 状态转移噪声
        self.Q = block_diag(0.01, 0.01, 0.01)

        # 测量噪声
        self.R_image = block_diag(0.1, 0.1, 0.1)  # 图像噪声
        self.R_wheel = block_diag(0.05, 0.05, 0.05)  # 轮速噪声

        # 上次时间戳
        self.last_timestamp = None

    def image_odometry_callback(self, msg):
        self.update_state_with_measurement(msg, self.R_image)

    def wheel_odometry_callback(self, msg):
        self.update_state_with_measurement(msg, self.R_wheel)

    def update_state_with_measurement(self, msg, R):
        """
        使用测量值更新状态（EKF更新步骤）
        """
        z = np.array([msg.pose.position.x, msg.pose.position.y, self.quaternion_to_yaw(
            msg.pose.orientation)])

        # H矩阵（测量模型）
        H = np.eye(3)

        # 计算Kalman增益
        S = H @ self.P @ H.T + R
        K = self.P @ H.T @ np.linalg.inv(S)

        # 状态更新
        y = z - H @ self.state  # 残差
        self.state += K @ y

        # 协方差更新
        I = np.eye(3)
        self.P = (I - K @ H) @ self.P

    def publish_fused_pose(self):
        """
        发布融合后的高频位姿
        """
        if self.last_timestamp is None:
            self.last_timestamp = self.get_clock().now()
            return

        # 时间增量
        current_time = self.get_clock().now()
        dt = (current_time - self.last_timestamp).nanoseconds * 1e-9
        self.last_timestamp = current_time

        # 状态预测
        self.predict_state(dt)

        # 发布位姿
        fused_pose = PoseStamped()
        fused_pose.header.stamp = self.get_clock().now().to_msg()
        fused_pose.header.frame_id = 'map'
        fused_pose.pose.position.x = self.state[0]
        fused_pose.pose.position.y = self.state[1]
        fused_pose.pose.position.z = 0.0
        fused_pose.pose.orientation = self.yaw_to_quaternion(self.state[2])

        print(f"融合里程计输出实时位置为: {fused_pose.pose.position.x:.2f}, {fused_pose.pose.position.y:.2f}")


        self.fused_pose_pub.publish(fused_pose)

    def predict_state(self, dt):
        """
        预测状态（EKF预测步骤）
        """
        # 状态转移模型
        F = np.eye(3)

        # 更新状态
        self.state = F @ self.state

        # 更新协方差
        self.P = F @ self.P @ F.T + self.Q

    @staticmethod
    def quaternion_to_yaw(q):
        """
        四元数转偏航角
        """
        siny_cosp = 2.0 * (q.w * q.z + q.x * q.y)
        cosy_cosp = 1.0 - 2.0 * (q.y * q.y + q.z * q.z)
        return np.arctan2(siny_cosp, cosy_cosp)

    @staticmethod
    def yaw_to_quaternion(yaw):
        """
        偏航角转四元数
        """
        from geometry_msgs.msg import Quaternion
        q = Quaternion()
        q.w = np.cos(yaw / 2.0)
        q.x = 0.0
        q.y = 0.0
        q.z = np.sin(yaw / 2.0)
        return q


def main(args=None):
    rclpy.init(args=args)
    node = EKFFusionNode()
    rclpy.spin(node)
    node.destroy_node()
    rclpy.shutdown()


if __name__ == '__main__':
    main()
