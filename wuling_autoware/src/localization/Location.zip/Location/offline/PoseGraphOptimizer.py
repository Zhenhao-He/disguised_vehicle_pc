import numpy as np
from scipy.optimize import minimize

class BundleAdjustmentOptimization:
    def __init__(self, corners_trajectory, vehicle_trajectory_initial):
        """
        :param corners_trajectory: 地标在车辆坐标系下的坐标 (15, 10, 2)
        :param vehicle_trajectory_initial: 车辆的初始位姿 (10, 3)，包括 x, y, yaw
        """
        self.corners_trajectory = corners_trajectory  # 地标轨迹 (num_landmarks, num_frames, 2)
        self.vehicle_trajectory_initial = vehicle_trajectory_initial  # 车辆轨迹 (num_frames, 3)

        self.num_landmarks = corners_trajectory.shape[0]  # 地标数量
        self.num_frames = corners_trajectory.shape[1]  # 帧数

    def transform_to_global(self, local_points, vehicle_pose):
        """
        将地标从车辆坐标系转换到全局坐标系
        :param local_points: 地标在车辆坐标系下的坐标 (num_landmarks, 2)
        :param vehicle_pose: 车辆的全局坐标系下的位姿 (x, y, yaw)
        :return: 地标在全局坐标系下的坐标
        """
        x, y, yaw = vehicle_pose
        rotation_matrix = np.array([[np.cos(yaw), -np.sin(yaw)],
                                    [np.sin(yaw), np.cos(yaw)]])
        global_points = local_points @ rotation_matrix.T + np.array([x, y])
        return global_points
    
    def residuals(self, params):
        """
        计算优化误差，params 包含优化后的地标位置和车辆轨迹
        :param params: 优化参数，包含每帧车辆位姿和地标全局坐标
        :return: 损失值
        """
        # 提取车辆轨迹 (num_frames, 3)
        vehicle_trajectory = params[:self.num_frames * 3].reshape(self.num_frames, 3)
        
        # 提取地标的全局位置 (num_landmarks, 2)
        global_landmarks = params[self.num_frames * 3:].reshape(self.num_landmarks, 2)
        
        # 计算总的残差
        total_residual = 0.0
        
        for t in range(self.num_frames):
            # 获取车辆位姿
            vehicle_pose = vehicle_trajectory[t]
            
            # 获取当前帧所有地标在车辆坐标系下的坐标
            local_points = self.corners_trajectory[:, t, :]
            
            # 跳过不存在的地标（坐标为 0 的地标）
            valid_points_mask = np.any(local_points != 0, axis=1)
            local_points = local_points[valid_points_mask]
            
            # 将地标坐标从车辆坐标系转换为全局坐标系
            transformed_points = self.transform_to_global(local_points, vehicle_pose)
            
            # 计算每个地标的误差 (全局坐标与当前优化值的差异)
            residual = np.linalg.norm(transformed_points - global_landmarks[valid_points_mask], axis=1)
            total_residual += np.sum(residual**2)
        
        return total_residual
    
    def optimize(self):
        """
        优化函数：使用最小二乘法优化车辆轨迹和地标位置
        :return: 最优化结果
        """
        # 初始化优化参数 (车辆轨迹和地标位置)
        initial_params = np.hstack([self.vehicle_trajectory_initial.flatten(), np.zeros(self.num_landmarks * 2)])
        
        # 优化
        result = minimize(self.residuals, initial_params, method='L-BFGS-B')
        
        # 优化后的车辆轨迹和地标
        optimized_params = result.x
        
        optimized_vehicle_trajectory = optimized_params[:self.num_frames * 3].reshape(self.num_frames, 3)
        optimized_landmarks = optimized_params[self.num_frames * 3:].reshape(self.num_landmarks, 2)
        
        return optimized_vehicle_trajectory, optimized_landmarks


# # 使用示例
# # 假设 corners_trajectory 和 vehicle_trajectory_initial 是已知的
# # corners_trajectory.shape = (15, 10, 2) 代表15个地标在10帧内的车辆坐标系坐标
# # vehicle_trajectory_initial.shape = (10, 3) 代表10帧的全局位姿 (x, y, yaw)

# # 示例数据
# corners_trajectory = np.random.rand(15, 10, 2)  # 假设有15个地标，10帧数据
# vehicle_trajectory_initial = np.random.rand(10, 3)  # 假设有10帧车辆的位姿

# # 设置一些地标不存在的情况（坐标为零）
# corners_trajectory[0, 3, :] = [0, 0]  # 第 3 帧，地标 0 不存在
# corners_trajectory[5, 7, :] = [0, 0]  # 第 7 帧，地标 5 不存在

# optimizer = BundleAdjustmentOptimization(corners_trajectory, vehicle_trajectory_initial)
# optimized_vehicle_trajectory, optimized_landmarks = optimizer.optimize()

# print("Optimized Vehicle Trajectory:")
# print(optimized_vehicle_trajectory)

# print("Optimized Landmarks:")
# print(optimized_landmarks)
