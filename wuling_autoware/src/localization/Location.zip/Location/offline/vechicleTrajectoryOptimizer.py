import numpy as np
from scipy.optimize import least_squares

class VehicleTrajectoryOptimizer:
    def __init__(self, corners_trajectory, vehicle_trajectory_initial):
        """
        初始化优化器。
        
        :param corners_trajectory: numpy array of shape (15, 10, 2)
        :param vehicle_trajectory_initial: numpy array of shape (10, 3)
        """
        self.corners_trajectory = corners_trajectory  # 15 landmarks, 10 frames, (x, y)
        self.vehicle_trajectory_initial = vehicle_trajectory_initial  # 10 frames, (x, y, yaw)
        self.num_landmarks, self.num_frames, _ = corners_trajectory.shape

    def rotation_matrix(self, yaw):
        """
        根据yaw角生成二维旋转矩阵。
        
        :param yaw: 旋转角度（弧度）
        :return: 2x2 numpy array
        """
        cos_yaw = np.cos(yaw)
        sin_yaw = np.sin(yaw)
        return np.array([[cos_yaw, -sin_yaw],
                         [sin_yaw,  cos_yaw]])

    def pack_variables(self, vehicle_poses, landmarks):
        """
        将车辆位姿和地标位置打包成一个一维数组，用于优化。
        
        :param vehicle_poses: numpy array of shape (10, 3)
        :param landmarks: numpy array of shape (15, 2)
        :return: 1D numpy array
        """
        return np.hstack((vehicle_poses.flatten(), landmarks.flatten()))

    def unpack_variables(self, x):
        """
        将优化变量数组解包成车辆位姿和地标位置。
        
        :param x: 1D numpy array
        :return: tuple (vehicle_poses, landmarks)
        """
        vehicle_poses = x[:self.num_frames * 3].reshape((self.num_frames, 3))
        landmarks = x[self.num_frames * 3:].reshape((self.num_landmarks, 2))
        return vehicle_poses, landmarks

    def residuals(self, x):
        """
        计算所有观测的残差。
        
        :param x: 1D numpy array，包含车辆位姿和地标位置
        :return: 1D numpy array，所有残差的集合
        """
        vehicle_poses, landmarks = self.unpack_variables(x)
        res = []
        for frame in range(self.num_frames):
            x_v, y_v, yaw = vehicle_poses[frame]
            R = self.rotation_matrix(yaw)
            for landmark in range(self.num_landmarks):
                # 观测到的地标在车辆坐标系下的位置
                corner_vehicle = self.corners_trajectory[landmark, frame]
                # 通过车辆位姿转换到全局坐标系
                corner_predicted = R @ corner_vehicle + np.array([x_v, y_v])
                # 地标的全局位置
                corner_global = landmarks[landmark]
                # 残差
                res.append(corner_predicted - corner_global)
        return np.hstack(res)

    def optimize(self):
        """
        执行优化过程，返回优化后的车辆轨迹和地标位置。
        
        :return: tuple (optimized_vehicle_poses, optimized_landmarks)
        """
        # 初始猜测：使用初始车辆轨迹和将地标位置转换到全局坐标系
        # 这里我们需要一个初始地标位置的猜测。假设车辆的初始位姿是接近正确的，
        # 可以将地标的位置转换到全局坐标系作为初始地标位置。
        landmarks_initial = []
        for landmark in range(self.num_landmarks):
            # 平均地标位置转换到全局坐标系
            points = []
            for frame in range(self.num_frames):
                x_v, y_v, yaw = self.vehicle_trajectory_initial[frame]
                R = self.rotation_matrix(yaw)
                corner_global = R @ self.corners_trajectory[landmark, frame] + np.array([x_v, y_v])
                points.append(corner_global)
            landmarks_initial.append(np.mean(points, axis=0))
        landmarks_initial = np.array(landmarks_initial)

        # 打包初始变量
        x0 = self.pack_variables(self.vehicle_trajectory_initial, landmarks_initial)

        # 执行优化
        result = least_squares(self.residuals, x0, method='lm', verbose=2, max_nfev=1000)

        # 解包优化后的变量
        optimized_vehicle_poses, optimized_landmarks = self.unpack_variables(result.x)

        return optimized_vehicle_poses, optimized_landmarks

# 示例用法
if __name__ == "__main__":
    # 假设有15个地标，10帧观测，每个观测有x, y
    np.random.seed(42)
    corners_trajectory = np.random.randn(15, 10, 2)  # 示例数据
    vehicle_trajectory_initial = np.random.randn(10, 3)  # 示例初始车辆位姿 (x, y, yaw)

    optimizer = VehicleTrajectoryOptimizer(corners_trajectory, vehicle_trajectory_initial)
    optimized_vehicle_poses, optimized_landmarks = optimizer.optimize()

    print("优化后的车辆位姿：")
    print(optimized_vehicle_poses)
    print("\n优化后的地标全局位置：")
    print(optimized_landmarks)
