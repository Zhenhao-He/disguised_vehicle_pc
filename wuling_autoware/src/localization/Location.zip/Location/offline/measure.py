# -*-coding: UTF-8 -*-
# create by zhangyucheng 2024/11/15 in whut

import numpy as np
import math
class Measure:
    def __init__(self):
        # 滑动窗口内的观测
        self._pose_id = 0
        self._data = [[],[],[]]
        self._data_add_yaw = [[],[],[],[]]
        self.trajectory_array  = np.zeros((15, 10, 2), dtype=float)


    def GetMeasure(self, n):
        # 更新pose id
        self._pose_id = n
        self._data = [[],[],[]]