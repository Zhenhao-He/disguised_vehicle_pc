# coding:utf-8
# create by zhangyucheng 2024/11/15 in whut

import time
import sys
import os
import numpy as np
np.set_printoptions(threshold=np.inf)

from math import sin, cos
import math
from scipy import optimize
from measure import Measure
from frame import Frame
from mappoint import Mappoint
from vechicleTrajectoryOptimizer import VehicleTrajectoryOptimizer
from PoseGraphOptimizer import BundleAdjustmentOptimization


from two_point_tracking import find_common_points,estimate_motion_least_squares,estimate_motion_single_point
from scipy.spatial.transform import Rotation as R


class Slidewindow_graph:
    def __init__(self):
        self._max_window = 20
        # 滑动窗口中的frame集合
        self._frames_DB = []
        # 滑动窗口中mappoint集合，里面元素为字典(描述子->Mappoints类)
        self._mappoints_DB = {}
        self._state = np.array([])
        self._descriptor2state = {}
        self._frameid2state = {}
        self._jacobi = np.array([])
        self._error = np.array([])
        self._measure = Measure()

        self.x_front = 0
        self.y_front = 0

        self.x_back = 0
        self.y_back = 0
        
        self._prior_matrix = np.array([])
        self._prior_matrixb = np.array([])
        self._lastframe = Frame(0)

        self._coefficient = [[], []]
        self._measure_count = 0

        self.current_pose = np.eye(3)
        self.updated_pose = np.eye(3)

        self.last_rotation = 0
        self.last_translation = np.array([0, 0])

        # 设置初始位姿
        angle_degrees = 0
        angle_radians = np.radians(angle_degrees)
        transform_initial = np.array([
            [np.cos(angle_radians), -np.sin(angle_radians), 0],
            [np.sin(angle_radians),  np.cos(angle_radians), 0],
            [0, 0, 1]
        ])
        self.yaw_front = angle_degrees / 180 * math.pi
        self.yaw_front2 = 0

        # 更新当前位姿
        self.current_pose = self.current_pose @ transform_initial
        self.updated_pose = self.updated_pose @ transform_initial

        # draw
        self._esti_pose = [[],[]]
        self._f2ftrack = []
        self._f2ftrack_show = [[],[]]
        self._slideframes = [[], []]
        self._slidepoints = [[],[]]

        self.corners_trajectory  = np.zeros((15, 10, 2), dtype=float)
        self.vehicle_trajectory_initial  = np.zeros((10, 3), dtype=float)
        self.count = 0
        self.vehicle_trajectory_initial_list = []

    def Initialize(self, init_pose, measure):
        self._measure = measure
        newFrame = Frame(self._measure._pose_id)

        # 初始化第一帧位姿
        newFrame.set_pose(init_pose)
        # 初始化地图点位置
        for i in range(0, len(self._measure._data[0])):
            raw_measure = np.array([[self._measure._data[0][i]],[self._measure._data[1][i]]])
            # 当前帧中的地图像素点转换到地图坐标系
            mp_pose = np.dot(np.linalg.inv(newFrame._Rbm), raw_measure) + newFrame._tb  
            newmappoint = Mappoint()
            newmappoint.set_descriptor(self._measure._data[2][i])
            newmappoint.set_pose(mp_pose)
            newmappoint.add_frame(newFrame)

            newFrame.add_mappoint(newmappoint)
            newFrame.add_newmappoints(newmappoint)
            newFrame.add_measure(raw_measure, newmappoint._descriptor)
            self._mappoints_DB[newmappoint._descriptor] = newmappoint
        self._frames_DB.append(newFrame)
        self._lastframe = newFrame
        self.vehicle_trajectory_initial_list.append([0, 0, 0])

    def Update(self, measure, n):
        self.count = n
        # （1）更新新的观测
        self._measure = measure
        # （2）前端跟踪：通过F2F跟踪2个点，初始估计新的状态；并将新的状态加入图
        self.calculate_odometry()
        # （3）后端优化：利用滑窗内所有信息优化图
        self.Optimize_graph()
        # （4）保存信息，用于做图
        self.For_draw()


    def calculate_odometry(self):
      
        # newFrame = Frame(self._measure._pose_id)
        # points1_f = [value.flatten().tolist() for value in self._lastframe._measure.values()]
        # keys1 = list(self._lastframe._measure.keys())
        # for i in range(len(points1_f)):
        #     points1_f[i].append(keys1[i])
        # points2_f = np.array(self._measure._data).T.tolist()
        # points1_common_f, points2_common_f = find_common_points(points1_f, points2_f)
        # if len(points1_common_f) > 1:
        #     rotation, translation = estimate_motion_least_squares(points1_common_f, points2_common_f)
        #     self.last_rotation, self.last_translation = rotation, translation
        # else:
        #     rotation, translation = self.last_rotation, self.last_translation
        #     self.last_rotation, self.last_translation = rotation, translation
        # points2 = np.array(self._measure._data).T.tolist()
        # points1 = []
        # for i in range(len(points2)):
        #     if points2[i][2] in self._lastframe._seeDescriptor:
        #         point = []
        #         point.append(self._mappoints_DB[points2[i][2]]._pose[0][0])
        #         point.append(self._mappoints_DB[points2[i][2]]._pose[1][0])
        #         point.append(points2[i][2])
        #         points1.append(point)
        # points1_common, points2_common = find_common_points(points1, points2)
        # init_gs = np.array([[self._lastframe._pose[0][0]],[self._lastframe._pose[1][0]],[self._lastframe._pose[2][0]]])
     

        newFrame = Frame(self._measure._pose_id)
        points1 = [value.flatten().tolist() for value in self._lastframe._measure.values()]
        keys1 = list(self._lastframe._measure.keys())
        for i in range(len(points1)):
            points1[i].append(keys1[i])
        points2 = np.array(self._measure._data).T.tolist()
        points1_common, points2_common = find_common_points(points1, points2)
        if len(points1_common) > 1:
            rotation, translation = estimate_motion_least_squares(points1_common, points2_common)
            self.last_rotation, self.last_translation = rotation, translation
        else:
            rotation, translation = self.last_rotation, self.last_translation
            self.last_rotation, self.last_translation = rotation, translation

        transform = np.eye(3)
        transform[:2, :2] = R.from_euler('z', rotation).as_matrix()[:2, :2]
        transform[:2, 2] = translation
        # if self.count > 9:
        #     self.current_pose = self.updated_pose
        self.current_pose = self.updated_pose
        self.current_pose = self.current_pose @ transform
        x_front, y_front = self.current_pose[0, 2], self.current_pose[1, 2]
        self.yaw_front = np.arctan2(self.current_pose[1, 0], self.current_pose[0, 0])


        # self.corners_trajectory  = self._measure.trajectory_array
        # self.vehicle_trajectory_initial_list.append([x_front, y_front, self.yaw_front])
        # if self.count > 9:
        #     self.vehicle_trajectory_initial_list.pop(0)
        #     for idx, pose in enumerate(self.vehicle_trajectory_initial_list):
        #         self.vehicle_trajectory_initial[idx][0] = pose[0]
        #         self.vehicle_trajectory_initial[idx][1] = pose[1]
        #         self.vehicle_trajectory_initial[idx][2] = pose[2]

        #     optimizer = BundleAdjustmentOptimization(self.corners_trajectory, self.vehicle_trajectory_initial)
        #     optimized_vehicle_poses, optimized_landmarks  = optimizer.optimize()
        #     self.updated_pose = self.pose_to_transformation_matrix(optimized_vehicle_poses[-1][0], optimized_vehicle_poses[-1][1], optimized_vehicle_poses[-1][2])

        #     print("优化qian的车辆位姿：")
        #     print(self.vehicle_trajectory_initial[-1])
        #     print("优化后的车辆位姿：")
        #     print(optimized_vehicle_poses[-1])
        #     aa = 1


        # x1, y1 = self.updated_pose[0, 2], self.updated_pose[1, 2]
        # yaw1 = np.arctan2(self.updated_pose[1, 0], self.updated_pose[0, 0])
        # self.x_back = -x1
        # self.y_back = y1

        # degree = self.yaw_front * 180 / math.pi
        # print(degree)

        pose = np.array([[-x_front], [y_front], [-self.yaw_front]])
        self.x_front = -x_front
        self.y_front = y_front
        newFrame.set_pose(pose)

        # 根据当前帧的位置，来估计新增加mappoint的初始位置；老的mappoints位置不变
        for i in range(0, len(self._measure._data[0])):
            raw_measure = np.array([[self._measure._data[0][i]],[self._measure._data[1][i]]])
            if self._measure._data[2][i] in self._mappoints_DB:
                newFrame.add_mappoint(self._mappoints_DB[self._measure._data[2][i]])
                newFrame.add_measure(raw_measure, self._measure._data[2][i])
                self._mappoints_DB[self._measure._data[2][i]].add_frame(newFrame)
                continue
            else:
                pose = np.dot(np.linalg.inv(newFrame._Rbm), raw_measure) + newFrame._tb  
                newmappoint = Mappoint()
                newmappoint.set_descriptor(self._measure._data[2][i])
                newmappoint.set_pose(pose)
                newmappoint.add_frame(newFrame)

                newFrame.add_mappoint(newmappoint)
                newFrame.add_newmappoints(newmappoint)
                newFrame.add_measure(raw_measure, newmappoint._descriptor)
                self._mappoints_DB[newmappoint._descriptor] = newmappoint
        self._frames_DB.append(newFrame)
        self._lastframe = newFrame
 


    def Optimize_graph(self):

        self.Linearization()
        self.Iterative_optimize()
        self.Flush_graph()

        if len(self._frames_DB) > self._max_window:
            # self.Get_prior()
            self.Cut_window2()

    def Linearization(self):
        self.Assemble_state()
        self.Assemble_jacobi()

    # 构建状态向量
    def Assemble_state(self):
        self._state = np.array([])
        self._descriptor2state = {}
        self._frameid2state = {}
        self._measure_count = 0
        dim = 3*len(self._frames_DB) + 2*len(self._mappoints_DB)
        # print(f"当前滑动窗口中的帧数量: {len(self._frames_DB)}")
        self._state = np.resize(self._state, (dim, 1))
       
        index = 0 
        for i in range(0, len(self._frames_DB)):
            # 装配位姿向量(3*1)
            self._state[index:(index + 3), 0] = self._frames_DB[i]._pose[0:3, 0]
            #print(self._frames_DB[i]._pose[0:3, 0])
            self._frameid2state[self._frames_DB[i]._id] = index
            index = index + 3
            self._measure_count = self._measure_count + len(self._frames_DB[i]._seeMappints)

            # 装配地图点向量(2*1)
            # for j in range(0, len(self._frames_DB[i]._new_mappoint_state)):
            #     if not self._frames_DB[i]._new_mappoint_state[j]._descriptor in self._descriptor2state:
            #         self._state[index:(index + 2), 0] = self._frames_DB[i]._new_mappoint_state[j]._pose[0:2, 0]
            #         self._descriptor2state[self._frames_DB[i]._new_mappoint_state[j]._descriptor] = index
            #         index = index + 2
            
            for j in range(0, len(self._frames_DB[i]._seeMappints)):
                if not self._frames_DB[i]._seeMappints[j]._descriptor in self._descriptor2state:
                    self._state[index:(index + 2), 0] = self._frames_DB[i]._seeMappints[j]._pose[0:2, 0]
                    self._descriptor2state[self._frames_DB[i]._seeMappints[j]._descriptor] = index
                    index = index + 2

    # 构建error和雅可比矩阵
    # 雅可比矩阵用于线性化非线性误差函数和指导优化算法调整状态变量（位姿和地图点）以最小化误差。
    def Assemble_jacobi(self):
        self._jacobi = np.array([])
        self._error = np.array([])
        self._jacobi = np.resize(self._jacobi, (2 * self._measure_count, len(self._state)))
        self._error = np.resize(self._error, (2 * self._measure_count, 1))

        measure_index = 0
        for i in range(0, len(self._frames_DB)):
            for j in range(0, len(self._frames_DB[i]._seeMappints)):
                point_index = self._descriptor2state[self._frames_DB[i]._seeMappints[j]._descriptor]
                frame_index = self._frameid2state[self._frames_DB[i]._id]
                #print(frame_index)
                x_f = self._state[frame_index][0]
                y_f = self._state[frame_index + 1][0]
                theta = self._state[frame_index + 2][0]
                x_p = self._state[point_index][0]
                y_p = self._state[point_index + 1][0]
                #print(x_f)
                measure = self._frames_DB[i]._measure[self._frames_DB[i]._seeMappints[j]._descriptor]
                # 单一残差项对frame的2*3雅克比矩阵
                self._jacobi[measure_index][frame_index] = -cos(theta)
                #print(-cos(theta))
                self._jacobi[measure_index][frame_index+1] = -sin(theta)
                self._jacobi[measure_index][frame_index+2] = (x_f-x_p)*sin(theta)+(y_p-y_f)*cos(theta)
                self._jacobi[measure_index + 1][frame_index] = sin(theta)
                self._jacobi[measure_index+1][frame_index+1] = -cos(theta)
                self._jacobi[measure_index+1][frame_index+2] = (x_f-x_p)*cos(theta)+(y_f-y_p)*sin(theta)
                # 单一残差项对mappoint的2*2雅克比矩阵
                self._jacobi[measure_index][point_index] = cos(theta)
                self._jacobi[measure_index][point_index+1] = sin(theta)
                self._jacobi[measure_index+1][point_index] = -sin(theta)
                self._jacobi[measure_index+1][point_index+1] = cos(theta)

                # 残差向量
                self._error[measure_index][0] = (x_p-x_f)*cos(theta)+(y_p-y_f)*sin(theta) - measure[0][0]
                self._error[measure_index+1][0] = (x_f-x_p)*sin(theta)+(y_p-y_f)*cos(theta) - measure[1][0]

                measure_index = measure_index + 2
        #f = open("./a.txt", 'w+')
        #print(self._jacobi)
        #print >> f, self._jacobi

    # 高斯牛顿迭代
    def Iterative_optimize(self):
        sum = 0

        if len(self._prior_matrix) != 0:
            temp0 = np.zeros((len(self._state), len(self._state)))
            temp1 = np.zeros((len(self._state), 1))
            dim = len(self._state) - 2*len(self._lastframe._new_mappoint_state) - 3
            # temp0[0:dim, 0:dim] = self._prior_matrix
            # temp1[0:dim, 0] = self._prior_matrixb
            temp0[:self._prior_matrix.shape[0], :self._prior_matrix.shape[1]] = self._prior_matrix
            temp1[0:self._prior_matrixb.shape[0], 0] = self._prior_matrixb


            self._prior_matrix = temp0
            self._prior_matrixb = temp1
        count_op = 0
        while np.dot(self._error.T, self._error)[0][0] > 0.01 and sum < 10:
            count_op += 1
            learning_rate = 0.1  # 初始学习率
            # lambda_reg = 0.0001  # 正则化参数
            lambda_reg = 0.0001  # 正则化参数

            if len(self._prior_matrix) == 0:
                H = np.dot(self._jacobi.T, self._jacobi) + lambda_reg * np.identity(len(self._state))
                b = -np.dot(self._jacobi.T, self._error)
            else:
                H = np.dot(self._jacobi.T, self._jacobi) + lambda_reg * np.identity(len(self._state)) + self._prior_matrix
                b = -np.dot(self._jacobi.T, self._error) + self._prior_matrixb
            delta = np.linalg.solve(H, b)

            # # 更新线性化点
            # self._state = delta  + self._state
            self._state = self._state + learning_rate * delta
            learning_rate *= 1  # 每次迭代减小学习率
            # 更新雅克比
            self.Assemble_jacobi()
            # 更新残差向量
            sum = sum + 1

            print(np.dot(self._error.T, self._error)[0][0])

        print(count_op)
        #print(len(self._state))
        #exit()
        # print(sum)

    def pose_to_transformation_matrix(self, x, y, yaw):
        # 旋转矩阵部分
        rotation_matrix = np.array([
            [np.cos(yaw), -np.sin(yaw)],
            [np.sin(yaw), np.cos(yaw)]
        ])
        
        # 平移部分
        translation_vector = np.array([x, y])

        # 构建 3x3 的齐次变换矩阵
        transformation_matrix = np.eye(3)
        transformation_matrix[0:2, 0:2] = rotation_matrix
        transformation_matrix[0:2, 2] = translation_vector

        return transformation_matrix

    def Flush_graph(self):

        for i in range(0, len(self._frames_DB)):
            # 装配位姿向量(3*1)
            index = self._frameid2state[ self._frames_DB[i]._id]

            d = np.array([[0.0], [0.0], [0.0]])
            #print(index)
            d[0][0] = self._state[index, 0]
            d[1][0] = self._state[index+1, 0]
            d[2][0] = self._state[index+2, 0]
            #print(d)
            #print(self._state)
            #exit()
            self._frames_DB[i].set_pose(d)
            # 装配地图点向量(2*1)
            for j in range(0, len(self._frames_DB[i]._seeMappints)):
                temp_index = self._descriptor2state[self._frames_DB[i]._seeMappints[j]._descriptor] 
                self._frames_DB[i]._seeMappints[j]._pose[0:2, 0] = self._state[temp_index:(temp_index + 2), 0]
            # if i == len(self._frames_DB) - 1:
            #     T = self.pose_to_transformation_matrix(-d[0][0], d[1][0], -d[2][0])
            #     self.updated_pose = T

            self.updated_pose = self.pose_to_transformation_matrix(-self._frames_DB[i]._pose[0][0], self._frames_DB[i]._pose[1][0], -self._frames_DB[i]._pose[2][0])



    def Get_prior(self):
        dim = len(self._state)
        dim1 = 2 * len(self._frames_DB[0]._new_mappoint_state) + 3
        # debug
        # if len(self._frames_DB[0]._new_mappoint_state) == len(self._frames_DB[0]._seeDescriptor):
        #     print('ok')
        dim2 = dim - dim1
        measure_dim = 2 * len(self._frames_DB[0]._new_mappoint_state)
        J_old = self._jacobi[0:measure_dim, 0:dim]
        error_old = self._error[0:measure_dim, 0:1]
        if len(self._prior_matrix) > 0:
            H = np.dot(J_old.T, J_old) + 0.01 * np.identity(dim) + self._prior_matrix
            b = -np.dot(J_old.T, error_old) + self._prior_matrixb
        else:
            H = np.dot(J_old.T, J_old) + 0.01 * np.identity(dim) 
            b = -np.dot(J_old.T, error_old)           
        H21 = H[dim1:dim, 0:dim1]
        # f = open("./a.txt", 'w+')
        # print >> f, H21
        H11 = H[0:dim1, 0:dim1] 
        H12 = H[0:dim1, dim1:dim]
        H22 = H[dim1:dim, dim1:dim]
        b_old = b[0:dim1, 0]
        self._prior_matrix = H22 - np.dot(np.dot(H21, np.linalg.inv(H11)), H12)
        self._prior_matrixb = b[dim1:dim, 0] - np.dot(np.dot(H21, np.linalg.inv(H11)), b_old)
            
    def Cut_window(self):

        for i in range(0, len(self._frames_DB[0]._seeMappints)):
            mappoint0 = self._frames_DB[0]._seeMappints[0]
            del self._mappoints_DB[mappoint0._descriptor]
            self._measure_count = self._measure_count - len(mappoint0._seeFrames)
            for j in range(0, len(mappoint0._seeFrames)):
                frame0 = mappoint0._seeFrames[j]
                (frame0._seeMappints).remove(mappoint0)
                (frame0._seeDescriptor).remove(mappoint0._descriptor)
                del (frame0._measure)[mappoint0._descriptor]
        self._frames_DB.remove(self._frames_DB[0])
            
    def Cut_window2(self):

        self._frames_DB.remove(self._frames_DB[0])

    def For_draw(self):
        self._esti_pose[0].append(self._lastframe._pose[0][0])
        self._esti_pose[1].append(self._lastframe._pose[1][0])
        self._slideframes = [[], [], []]
        self._slidepoints = [[], []]
        for i in range(0, len(self._frames_DB)):
            self._slideframes[0].append(self._frames_DB[i]._pose[0][0])
            self._slideframes[1].append(self._frames_DB[i]._pose[1][0])
            self._slideframes[2].append(self._frames_DB[i]._pose[2][0])
            for j in range(0, len(self._frames_DB[i]._new_mappoint_state)):
                self._slidepoints[0].append(self._frames_DB[i]._new_mappoint_state[j]._pose[0][0])
                self._slidepoints[1].append(self._frames_DB[i]._new_mappoint_state[j]._pose[1][0])
        self._f2ftrack_show = [[],[]]
        for k in range(0, len(self._f2ftrack)):
            if self._f2ftrack[k] in self._mappoints_DB:
                self._f2ftrack_show[0].append(self._mappoints_DB[self._f2ftrack[k]]._pose[0][0])
                self._f2ftrack_show[1].append(self._mappoints_DB[self._f2ftrack[k]]._pose[1][0])
