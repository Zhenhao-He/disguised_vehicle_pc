#!/bin/bash

evo_ape tum ground_truth/5/utm_trans.txt output/image/backend.txt -p
