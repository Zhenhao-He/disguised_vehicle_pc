# coding:utf-8
# create by zhangyucheng 2024/11/15 in whut

import numpy as np
import matplotlib.pyplot as plt
from numpy import linspace
import math



class Draw:
    def __init__(self, slidewindow_graph):
        self._fig = plt.figure(figsize=(10,10))
        self._graph = slidewindow_graph

        #设置图形元素
        ## 当前真实位置
        self._x = 0
        self._y = 0

        ## 当前估计位置
        self.x_front = []
        self.y_front = []

        ## 当前优化后的位置
        self.x_back = []
        self.y_back = []

        self.x2 = []
        self.y2 = []

        ## 优化后的地图点位置
        self.mappoints_x = []
        self.mappoints_y = []

    # 画出当前时刻路标点位置, 真实运动点,估计运动点
    def Show_result(self):
        # 真实位置(x,y)
        # self._x = [self._movemodel._currentpose[0,0]]
        # self._y = [self._movemodel._currentpose[1, 0]]

        self.x_front.append(self._graph.x_front)
        self.y_front.append(self._graph.y_front)

        # self.x2.append(self._graph.x_back)
        # self.y2.append(self._graph.y_back)

        if len(self._graph._slideframes[1]) == 0:
            self.x_back.append(0)
            self.y_back.append(0)
        else:
            self.x_back.append(self._graph._slideframes[0][-1])
            self.y_back.append(self._graph._slideframes[1][-1])

        # 全局优化后的轨迹
        # self.x_back = [element for element in self._graph._slideframes[0]]
        # self.y_back = [element for element in self._graph._slideframes[1]]

        self.mappoints_x = []
        self.mappoints_y = []

        for key, value in self._graph._mappoints_DB.items():
            self.mappoints_x.append(value._pose[0])
            self.mappoints_y.append(value._pose[1])

        # 作图
        plt.clf()
        plt.xlabel('x/m')
        plt.ylabel('y/m')
        plt.title('parking')
        plt.axis([-15, 15, -15, 15])
        ax = plt.gca()
        ax.set_aspect(1)
        plt.plot(self.x_front, self.y_front, color= 'b')
        # plt.plot(self.x2, self.y2, color='r')
        plt.plot(self.x_back, self.y_back, color='r')
        plt.plot(self.mappoints_x, self.mappoints_y, 'o', label="MapPoints")  # 'o' 表示绘制散点

        plt.pause(0.01)

  




