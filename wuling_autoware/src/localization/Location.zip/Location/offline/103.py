import numpy as np
import pandas as pd
import math

# 定义一个函数，将四元数转换为yaw
def quaternion_to_yaw(qx, qy, qz, qw):
    siny_cosp = 2 * (qw * qz + qx * qy)
    cosy_cosp = 1 - 2 * (qy**2 + qz**2)
    yaw = math.atan2(siny_cosp, cosy_cosp)
    return yaw

# 时间对齐并插值到100Hz
def align_to_100hz(visual_data, wheel_data):
    # 提取时间戳范围
    start_time = max(visual_data[0][0], wheel_data[0][0])  # 对齐起始时间
    end_time = min(visual_data[-1][0], wheel_data[-1][0])  # 对齐结束时间

    # 生成均匀的100Hz时间戳
    timestamps_100hz = np.arange(start_time, end_time, 0.01)  # 时间间隔为0.01s (100Hz)

    # 分别对x, y, 和 yaw 进行插值
    def interpolate(data, col_index):
        times = [row[0] for row in data]
        values = [row[col_index] for row in data]
        return np.interp(timestamps_100hz, times, values)

    # 视觉数据插值
    visual_x = interpolate(visual_data, 1)
    visual_y = interpolate(visual_data, 2)
    visual_yaw = interpolate(visual_data, -1)

    # 轮速计数据插值
    wheel_x = interpolate(wheel_data, 1)
    wheel_y = interpolate(wheel_data, 2)
    wheel_yaw = interpolate(wheel_data, -1)

    # 构建插值后的数据列表
    visual_interp = [[t, x, y, yaw] for t, x, y, yaw in zip(timestamps_100hz, visual_x, visual_y, visual_yaw)]
    wheel_interp = [[t, x, y, yaw] for t, x, y, yaw in zip(timestamps_100hz, wheel_x, wheel_y, wheel_yaw)]

    return visual_interp, wheel_interp

# 扩展卡尔曼滤波器 (EKF) 的实现
def ekf_fusion(visual_data, wheel_data):
    state = np.array([0.0, 0.0, 0.0])  # 初始状态向量 [x, y, yaw]
    P = np.eye(3) * 1e-3  # 初始协方差矩阵
    Q = np.diag([0.1, 0.1, 0.01])  # 过程噪声
    R_visual = np.diag([0.5, 0.5, 0.1])  # 视觉测量噪声
    R_wheel = np.diag([0.2, 0.2, 0.05])  # 轮速测量噪声

    def predict(F, Q, state, P):
        state = F @ state
        P = F @ P @ F.T + Q
        return state, P

    def update(H, R, z, state, P):
        y = z - H @ state  # 残差
        S = H @ P @ H.T + R  # 残差协方差
        K = P @ H.T @ np.linalg.inv(S)  # 卡尔曼增益
        state = state + K @ y
        P = (np.eye(len(P)) - K @ H) @ P
        return state, P

    fused_data = []

    for v_data, w_data in zip(visual_data, wheel_data):
        z_visual = np.array([v_data[1], v_data[2], v_data[-1]])
        z_wheel = np.array([w_data[1], w_data[2], w_data[-1]])
        H_visual = np.eye(3)
        H_wheel = np.eye(3)

        dt = 0.01  # 时间步长 (100Hz)
        F = np.array([
            [1, 0, -dt * state[2]],
            [0, 1, dt * state[2]],
            [0, 0, 1]
        ])
        
        state, P = predict(F, Q, state, P)
        state, P = update(H_visual, R_visual, z_visual, state, P)
        state, P = update(H_wheel, R_wheel, z_wheel, state, P)

        # 将状态存储，格式为 [timestamp, x, y, z, qx, qy, qz, qw]
        timestamp = v_data[0]
        x, y, yaw = state
        # qx, qy, qz, qw = 0, 0, np.sin(yaw / 2), np.cos(yaw / 2)
        # fused_data.append([timestamp, x, y, 0, qx, qy, qz, qw])
        qx, qy, qz, qw = 0, 0, np.sin(w_data[-1] / 2), np.cos(w_data[-1] / 2)
        fused_data.append([timestamp, w_data[1], v_data[2], 0, qx, qy, qz, qw])


    return fused_data

# 数据读取与预处理
wheel_data = pd.read_csv(
    "/home/parking/SLAM/111/5/odometry.txt", 
    sep=" ", 
    header=None, 
    names=["timestamp", "x", "y", "z", "qx", "qy", "qz", "qw"]
)
wheel_data_list = wheel_data.values.tolist()
for row in wheel_data_list:
    qx, qy, qz, qw = row[-4:]
    yaw = quaternion_to_yaw(qx, qy, qz, qw)
    row[-4:] = [yaw]

visual_data = pd.read_csv(
    "/home/parking/SLAM/output/5/frontend.txt", 
    sep=" ", 
    header=None, 
    names=["timestamp", "x", "y", "z", "qx", "qy", "qz", "qw"]
)
visual_data_list = visual_data.values.tolist()
for row in visual_data_list:
    qx, qy, qz, qw = row[-4:]
    yaw = quaternion_to_yaw(qx, qy, qz, qw)
    row[-4:] = [-yaw]

# 时间对齐与数据融合
aligned_visual_data, aligned_wheel_data = align_to_100hz(visual_data_list, wheel_data_list)
fused_data = ekf_fusion(aligned_visual_data, aligned_wheel_data)

# 保存到TUM格式的文件中
output_path = "/home/parking/SLAM/fused_data.txt"
with open(output_path, "w") as f:
    for data in fused_data:
        line = " ".join(map(str, data))
        f.write(line + "\n")

print(f"Fused data saved to {output_path}")
