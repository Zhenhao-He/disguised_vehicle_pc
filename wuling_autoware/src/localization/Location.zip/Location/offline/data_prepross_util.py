import re
import json
import numpy as np
from scipy.optimize import linear_sum_assignment


def parse_predictions(file_path):
    with open(file_path, 'r') as file:
        data = file.read()

    # 匹配图片名称和预测结果
    results = re.findall(r'图片名称:\s*(\S+)\n预测结果:\n(\[\[.*?\]\])', data, re.DOTALL)
    parsed_data = {}

    for image_name, predictions in results:
        # 将预测结果字符串转换为列表
        parsed_predictions = eval(predictions)
        parsed_data[image_name] = parsed_predictions

    return parsed_data

def save_to_json(data, output_path):
    with open(output_path, 'w', encoding='utf-8') as json_file:
        json.dump(data, json_file, ensure_ascii=False, indent=4)

def load_json(file_path):
    with open(file_path, 'r', encoding='utf-8') as file:
        data = json.load(file)
    return data

def calculate_coordinates(data, width, height):
    coordinates = {}
    for image_name, predictions in data.items():
        image_coords = []
        for pred in predictions:
            # 计算坐标 (p0_x, p0_y)
            p0_x = (pred[0] + pred[2]) / 1280 * width
            p0_y = (pred[1] + pred[3]) / 1280 * height
            image_coords.append((p0_x, p0_y))
        coordinates[image_name] = image_coords
    return coordinates

def save_to_json(data, output_path):
    # 按照图片名称中的数字排序字典
    sorted_data = dict(sorted(data.items(), key=lambda item: int(re.search(r'\d+', item[0]).group())))
    with open(output_path, 'w', encoding='utf-8') as json_file:
        json.dump(sorted_data, json_file, ensure_ascii=False, indent=4)

def calculate_distance_matrix(points1, points2):
    """计算两帧中的点之间的距离矩阵"""
    num_points1 = len(points1)
    num_points2 = len(points2)
    distance_matrix = np.zeros((num_points1, num_points2))
    for i, p1 in enumerate(points1):
        for j, p2 in enumerate(points2):
            distance_matrix[i, j] = np.sqrt((p1[0] - p2[0]) ** 2 + (p1[1] - p2[1]) ** 2)
    return distance_matrix

def track_points(data, max_distance=200, history_frames=8):
    """对不同帧中的点进行跟踪并分配唯一 ID，保留短暂丢失的 ID"""
    track_id = 0
    tracked_data = {}
    previous_frame_points = []
    previous_ids = []
    id_history = {}  # 用于存储每个 ID 的最近位置和帧数

    for frame_idx, (frame_name, points) in enumerate(sorted(data.items())):
        if not previous_frame_points:
            # 初始化第一帧的跟踪 ID
            current_ids = list(range(track_id, track_id + len(points)))
            for idx, point in enumerate(points):
                id_history[current_ids[idx]] = {"point": point, "last_seen": frame_idx}
            track_id += len(points)
        else:
            # 计算当前帧和上一帧点的距离矩阵
            distance_matrix = calculate_distance_matrix(previous_frame_points, points)
            row_ind, col_ind = linear_sum_assignment(distance_matrix)

            # 分配跟踪 ID
            current_ids = [-1] * len(points)
            assigned_ids = set()  # 用于检测重复 ID
            for r, c in zip(row_ind, col_ind):
                if distance_matrix[r, c] < max_distance and previous_ids[r] not in assigned_ids:
                    current_ids[c] = previous_ids[r]
                    assigned_ids.add(previous_ids[r])
                else:
                    current_ids[c] = -1

            # 处理未匹配点
            for i, id_val in enumerate(current_ids):
                if id_val == -1:
                    # 尝试匹配历史 ID
                    matched_id = None
                    for past_id, info in id_history.items():
                        if frame_idx - info["last_seen"] <= history_frames and past_id not in assigned_ids:
                            dist = np.sqrt((info["point"][0] - points[i][0]) ** 2 +
                                           (info["point"][1] - points[i][1]) ** 2)
                            if dist < max_distance:
                                matched_id = past_id
                                break
                    if matched_id is not None:
                        current_ids[i] = matched_id
                        assigned_ids.add(matched_id)
                    else:
                        # 分配新 ID
                        current_ids[i] = track_id
                        assigned_ids.add(track_id)
                        track_id += 1

            # 更新历史信息
            for i, point in enumerate(points):
                id_history[current_ids[i]] = {"point": point, "last_seen": frame_idx}

            # 清理长时间未匹配的 ID
            to_remove = [tid for tid, info in id_history.items() if frame_idx - info["last_seen"] > history_frames]
            for tid in to_remove:
                del id_history[tid]

        # 保存当前帧的点和跟踪 ID
        tracked_data[frame_name] = [(current_ids[i], points[i][0], points[i][1]) for i in range(len(points))]

        # 更新上一帧的数据
        previous_frame_points = points
        previous_ids = current_ids

    return tracked_data

def save_to_json2(data, output_path):
    """保存数据为 JSON 文件"""
    with open(output_path, 'w', encoding='utf-8') as json_file:
        json.dump(data, json_file, ensure_ascii=False, indent=4)

# 使用示例
predictions_txt_path = '../detection/prediction6.txt'  # 请将此替换为你的文件路径
predictions_json_path = './output/predictions.json'  # 输出的 JSON 文件路径
# 解析并保存为 JSON
parsed_data = parse_predictions(predictions_txt_path)
save_to_json(parsed_data, predictions_json_path)
print(f"预测结果已保存到 {predictions_json_path}")

# 使用示例
input_json_path = './output/predictions.json'  # 输入的 JSON 文件路径
output_json_path = './output/processed_coordinates.json'  # 输出的 JSON 文件路径
width, height = 1151, 1424  # 图像的宽度和高度
# 加载 JSON 文件，计算坐标并保存为 JSON
data = load_json(input_json_path)
coordinates = calculate_coordinates(data, width, height)
save_to_json(coordinates, output_json_path)
print(f"计算后的坐标已保存到 {output_json_path}")

# 使用示例
input_json_path = './output/processed_coordinates.json'  # 输入的 JSON 文件路径
output_json_path = './output/tracked_coordinates.json'  # 输出的 JSON 文件路径
# 加载 JSON 文件并跟踪点
data = load_json(input_json_path)
tracked_data = track_points(data)
save_to_json2(tracked_data, output_json_path)
print(f"带跟踪 ID 的坐标已保存到 {output_json_path}")
