# coding:utf-8
# create by zhangyucheng 2024/11/15 in whut

import numpy as np
import json
import os
import re
from scipy.spatial.transform import Rotation as R

import math
from datetime import datetime

from draw import Draw
from measure import Measure
from slidewindow_graph import Slidewindow_graph
from save_trajectories import *


def load_tracked_data(file_path):
    """加载带有跟踪 ID 的点数据"""
    with open(file_path, 'r', encoding='utf-8') as file:
        data = json.load(file)
    return data

def extract_timestamp(filename):
    """从文件名中提取时间戳，并转换为浮点格式"""
    timestamp_str = filename.split('_')[1].split('.')[0]
    timestamp = float(timestamp_str[:10] + '.' + timestamp_str[10:])
    return timestamp

def load_velocity_data(file_path="velocity.txt"):
    """
    读取速度日志文件，解析时间戳、左轮和右轮速度。
    返回数据列表 [(timestamp, left_velocity, right_velocity), ...]
    """
    data = []
    with open(file_path, "r") as file:
        for line in file:
            parts = line.strip().split(",")
            timestamp = float(parts[0])
            left_velocity = float(parts[1])
            right_velocity = float(parts[2])
            data.append((timestamp, left_velocity, right_velocity))
    return data

def calculate_odometry(data, output_file="./wheel/odometry.txt"):
    """
    根据轮速数据推算机器人的里程计，并按TUM格式保存到文件。
    """
    previous_timestamp = None

    with open(output_file, "w") as file:
        for timestamp, left_velocity, right_velocity in data:
            left_velocity = -left_velocity
            right_velocity = -right_velocity
            # 计算时间步长 dt
            if previous_timestamp is None:
                previous_timestamp = timestamp
                continue
            dt = timestamp - previous_timestamp
            previous_timestamp = timestamp

            # 计算左右轮的平均线速度
            robot_liner_x_ = (left_velocity + right_velocity) / 2.0

            # 计算偏航角变化（delta_yaw）
            delta_yaw = (right_velocity - left_velocity) * dt / C5_DISTANCE_WHEELS
            # delta_yaw = (left_velocity - right_velocity) * dt / C5_DISTANCE_WHEELS


            # 计算位置变化（delta_x, delta_y）
            delta_x = (robot_liner_x_ * math.cos(robot_status['position_yaw_']) - robot_liner_y_ * math.sin(robot_status['position_yaw_'])) * dt
            delta_y = (robot_liner_x_ * math.sin(robot_status['position_yaw_']) + robot_liner_y_ * math.cos(robot_status['position_yaw_'])) * dt

            # 更新机器人位置
            robot_status['position_x_'] += delta_x
            robot_status['position_y_'] += delta_y
            robot_status['position_yaw_'] += delta_yaw

            # 计算四元数表示旋转
            qx, qy, qz, qw = euler_to_quaternion(robot_status['position_yaw_'])

            # 获取当前时间戳（秒，精确到纳秒）
            timestamp = timestamp - 0.07
            timestamp_sec = int(timestamp)
            timestamp_nsec = int((timestamp - timestamp_sec) * 1e9)
            # timestamp_nsec = timestamp_nsec - 70000000

            # 将纳秒部分格式化为9位，不足前面补0
            timestamp_nsec_str = f"{timestamp_nsec:09d}"

            # 保存位姿信息，按TUM格式写入
            # file.write(f"{timestamp_sec+42070}.{timestamp_nsec_str} {robot_status['position_x_']} {robot_status['position_y_']} 0.0 {qx} {qy} {qz} {qw}\n")
            file.write(f"{timestamp_sec}.{timestamp_nsec_str} {robot_status['position_x_']} {robot_status['position_y_']} 0.0 {qx} {qy} {qz} {qw}\n")

            # 打印当前状态
            # print(f"Time: {timestamp}, Position: ({robot_status['position_x_']}, {robot_status['position_y_']}), Yaw: {robot_status['position_yaw_']}")

def euler_to_quaternion(yaw):
    """
    将欧拉角（yaw）转换为四元数。
    假设只有绕z轴的旋转（2D平面旋转）。
    """
    qw = math.cos(yaw / 2.0)
    qx = 0.0
    qy = 0.0
    qz = math.sin(yaw / 2.0)
    return qx, qy, qz, qw

estimate_init_pose = np.array([[0], [0], [0]])
slidewindow_graph = Slidewindow_graph()
draw = Draw(slidewindow_graph)
n = 0
sum = 5000
input_json_path = 'rtk/output/5/tracked_coordinates.json'
data = load_tracked_data(input_json_path)
odometry = []

C5_DISTANCE_WHEELS = 1.45  # 轮距，单位：米
robot_liner_y_ = 0.0  # 假设没有侧向速度
current_yaw_ = 0.0  # 初始朝向
robot_status = {
    'position_x_': 0.0,  # 初始位置
    'position_y_': 0.0,
    'position_yaw_': current_yaw_
}

# 加载数据并计算里程计，保存为TUM格式
data_wheel = load_velocity_data("./wheel/velocity.txt")
# calculate_odometry(data_wheel)

while n != sum:

    measure = Measure()
    measure._pose_id = n
    n_th_key = list(data.keys())[n]  # 获取第 n 个键
    for i in range(len(data[n_th_key])):
        measure._data[1].append(-(data[n_th_key][i][1] - 575)*0.0094)
        measure._data[0].append(-(data[n_th_key][i][2] - 810)*0.0094)
        measure._data[2].append(data[n_th_key][i][0])

    if n == 0:
        slidewindow_graph.Initialize(estimate_init_pose, measure)
    else:
        slidewindow_graph.Update(measure) 

    draw.Show_result()

    frontend_txt_path = 'output/frontend.txt'
    backend_txt_path = 'output/backend.txt'

    save_frontend_to_txt(slidewindow_graph, data, n, odometry, frontend_txt_path)
    save_backend_to_txt(slidewindow_graph, data, n, odometry, backend_txt_path)


    print(n)
    # print(f"车位右上角点的位置为: {slidewindow_graph._mappoints_DB[1]._pose[0][0]:.2f}, {slidewindow_graph._mappoints_DB[1]._pose[1][0]:.2f}")



    n = n + 1

