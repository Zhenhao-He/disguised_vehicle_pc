import json
import os
import re
import numpy as np
from scipy.optimize import linear_sum_assignment
from scipy.spatial.transform import Rotation as R

import rclpy
from rclpy.node import Node
from std_msgs.msg import String

from draw import Draw
from measure import Measure
from slidewindow_graph import Slidewindow_graph
from save_trajectories import *

from geometry_msgs.msg import PoseStamped

from builtin_interfaces.msg import Time


class ParkingLineTracker(Node):
    def __init__(self):
        super().__init__('parking_line_tracker')

        # 同于跟踪的参数
        self.width = 1151
        self.height = 1424
        self.max_distance = 200
        self.history_frames = 8
        self.track_id = 0
        self.previous_frame_points = []
        self.previous_ids = []
        self.id_history = {}
        self.frame_counter = 0  # 添加帧计数器

        self.estimate_init_pose = np.array([[0], [0], [0]]) # 帧初始位姿
        self.scale = 0.0094 # BEV图像尺度
        self.rear_x = 575 # 后轴中心x坐标
        self.rear_y = 810 # 后轴中心y坐标

        self.slidewindow_graph = Slidewindow_graph()
        self.draw = Draw(self.slidewindow_graph)
        self.odometry = []

        # 订阅话题
        self.subscription = self.create_subscription(
            String,
            'image_predictions',
            self.listener_callback,
            10
        )
        # 创建Publisher来发布PoseStamped消息
        self.pose_publisher = self.create_publisher(PoseStamped, '/location/image_odometry', 10)
        self.get_logger().info('Node initialized and subscribing to image_predictions.')

    def listener_callback(self, msg):
        try:
            data = eval(msg.data)  # 将JSON字符串转换为Python字典
            timestamp = data.get("timestamp", 0)  # 从消息中提取时间戳
            marking_points = data.get("marking_points", [])
            points = self.calculate_coordinates(marking_points)
            # points_yaw = self.calculate_coordinates(marking_points)


            # 调用 track_points 时传入帧计数器
            tracked_points = self.track_points(points, self.frame_counter)

            self.location_and_publish(tracked_points, timestamp, self.frame_counter)
            self.frame_counter += 1  # 更新帧计数器

        except Exception as e:
            self.get_logger().error(f"Error processing message: {e}")

    def calculate_coordinates(self, corners):
        """将角点坐标转换为实际像素坐标"""
        points = []
        for pred in corners:
            p0_x = (pred[0] + pred[2]) / 1280 * self.width
            p0_y = (pred[1] + pred[3]) / 1280 * self.height
            p0_yaw = pred[5]
            points.append((p0_x, p0_y, p0_yaw))
        return points

    def calculate_distance_matrix(self, points1, points2):
        """计算两帧中的点之间的距离矩阵"""
        num_points1 = len(points1)
        num_points2 = len(points2)
        distance_matrix = np.zeros((num_points1, num_points2))
        for i, p1 in enumerate(points1):
            for j, p2 in enumerate(points2):
                distance_matrix[i, j] = np.sqrt((p1[0] - p2[0]) ** 2 + (p1[1] - p2[1]) ** 2)
        return distance_matrix

    def track_points(self, points, frame_idx):
        """对不同帧中的点进行跟踪并分配唯一 ID，保留短暂丢失的 ID"""
        if not self.previous_frame_points:
            # 初始化第一帧的跟踪 ID
            current_ids = list(range(self.track_id, self.track_id + len(points)))
            for idx, point in enumerate(points):
                self.id_history[current_ids[idx]] = {"point": point, "last_seen": frame_idx}
            self.track_id += len(points)
        else:
            # 计算距离矩阵
            distance_matrix = self.calculate_distance_matrix(self.previous_frame_points, points)
            row_ind, col_ind = linear_sum_assignment(distance_matrix)

            # 分配跟踪 ID
            current_ids = [-1] * len(points)
            assigned_ids = set()
            for r, c in zip(row_ind, col_ind):
                if distance_matrix[r, c] < self.max_distance and self.previous_ids[r] not in assigned_ids:
                    current_ids[c] = self.previous_ids[r]
                    assigned_ids.add(self.previous_ids[r])
                else:
                    current_ids[c] = -1

            # 未匹配点分配新 ID
            for i, id_val in enumerate(current_ids):
                if id_val == -1:
                    # 尝试匹配历史 ID
                    matched_id = None
                    for past_id, info in self.id_history.items():
                        if frame_idx - info["last_seen"] <= self.history_frames and past_id not in assigned_ids:
                            dist = np.sqrt((info["point"][0] - points[i][0]) ** 2 +
                                           (info["point"][1] - points[i][1]) ** 2)
                            if dist < self.max_distance:
                                matched_id = past_id
                                break
                    if matched_id is not None:
                        current_ids[i] = matched_id
                        assigned_ids.add(matched_id)
                    else:
                        # 分配新 ID
                        current_ids[i] = self.track_id
                        assigned_ids.add(self.track_id)
                        self.track_id += 1

            # 更新历史信息
            for i, point in enumerate(points):
                self.id_history[current_ids[i]] = {"point": point, "last_seen": frame_idx}

            # 清理长时间未匹配的 ID
            to_remove = [tid for tid, info in self.id_history.items() if frame_idx - info["last_seen"] > self.history_frames]
            for tid in to_remove:
                del self.id_history[tid]

        # 更新上一帧的数据
        self.previous_frame_points = points
        self.previous_ids = current_ids

        # 返回当前帧的跟踪结果
        return [(current_ids[i], points[i][0], points[i][1], points[i][2]) for i in range(len(points))]

    def location_and_publish(self, tracked_points, timestamp, n):
        #开始定位
        measure = Measure()
        measure._pose_id = n
        for tid, x, y, yaw in tracked_points:
            measure._data[1].append(-(x - self.rear_x) * self.scale)
            measure._data[0].append(-(y - self.rear_y) * self.scale)
            measure._data[2].append(tid) 

            #添加角点朝向
            measure._data_add_yaw[1].append(-(x - self.rear_x) * self.scale)
            measure._data_add_yaw[0].append(-(y - self.rear_y) * self.scale)
            measure._data_add_yaw[2].append(tid)  
            measure._data_add_yaw[3].append(yaw) 
            
        if n == 0:
            self.slidewindow_graph.Initialize(self.estimate_init_pose, measure)
        else:
            self.slidewindow_graph.Update(measure) 

        print(f"视觉里程计输出的实时位置为: {self.slidewindow_graph.x:.2f}, {self.slidewindow_graph.y:.2f}")

        # 发布机器人位姿

        self.publish_pose(self.slidewindow_graph.x, self.slidewindow_graph.y, self.slidewindow_graph._yaw, timestamp)


        #可视化和保存结果
        # self.draw.Show_result()
        frontend_txt_path = 'output/frontend.txt'
        backend_txt_path = 'output/backend.txt'

        save_frontend_to_txt_online(self.slidewindow_graph, n, self.odometry, frontend_txt_path, timestamp)
        save_backend_to_txt_online(self.slidewindow_graph, n, self.odometry, backend_txt_path, timestamp)


    @staticmethod
    def euler_to_quaternion(yaw):
        """
        将欧拉角（yaw）转换为四元数。
        假设只有绕z轴的旋转（2D平面旋转）。
        """
        qw = math.cos(yaw / 2.0)
        qx = 0.0
        qy = 0.0
        qz = math.sin(yaw / 2.0)
        return qx, qy, qz, qw


    def publish_pose(self, x, y, yaw, timestamp):
        """
        发布机器人的位姿信息（Position + Quaternion）。
        """
        # 创建 PoseStamped 消息
        pose_msg = PoseStamped()

        # 创建时间戳消息
        time_msg = Time()
        time_msg.sec = int(timestamp)  # 时间戳的秒部分
        time_msg.nanosec = int((timestamp - int(timestamp)) * 1e9)  # 时间戳的小数部分转纳秒

        # 设置时间戳
        pose_msg.header.stamp = time_msg

        pose_msg.header.frame_id = 'map'  # 可以根据需要修改坐标系

        # 设置位置信息
        pose_msg.pose.position.x = float(x)
        pose_msg.pose.position.y = float(y)
        pose_msg.pose.position.z = 0.0  # 假设机器人只在平面上运动

        # 设置四元数表示的朝向
        qx, qy, qz, qw = self.euler_to_quaternion(yaw)
        pose_msg.pose.orientation.x = qx
        pose_msg.pose.orientation.y = qy
        pose_msg.pose.orientation.z = qz
        pose_msg.pose.orientation.w = qw

        # 发布消息
        self.pose_publisher.publish(pose_msg)

def main(args=None):
    rclpy.init(args=args)
    node = ParkingLineTracker()
    rclpy.spin(node)
    node.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()
