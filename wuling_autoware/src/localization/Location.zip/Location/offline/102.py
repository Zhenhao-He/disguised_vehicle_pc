import numpy as np
import pandas as pd
from scipy.interpolate import interp1d
import math

# 定义一个函数，将四元数转换为yaw
def quaternion_to_yaw(qx, qy, qz, qw):
    siny_cosp = 2 * (qw * qz + qx * qy)
    cosy_cosp = 1 - 2 * (qy**2 + qz**2)
    yaw = math.atan2(siny_cosp, cosy_cosp)
    return yaw

# 时间对齐和插值
def align_data_by_interpolation(visual_data, wheel_data):
    aligned_wheel = []
    wheel_timestamps = [w_data[0] for w_data in wheel_data]
    wheel_states = np.array([w_data[1:] for w_data in wheel_data])  # x, y, z, yaw

    for v_data in visual_data:
        v_time = v_data[0]
        if v_time <= wheel_timestamps[0]:
            aligned_state = wheel_states[0]
        elif v_time >= wheel_timestamps[-1]:
            aligned_state = wheel_states[-1]
        else:
            idx = np.searchsorted(wheel_timestamps, v_time)
            t1, t2 = wheel_timestamps[idx - 1], wheel_timestamps[idx]
            s1, s2 = wheel_states[idx - 1], wheel_states[idx]

            alpha = (v_time - t1) / (t2 - t1)
            aligned_state = (1 - alpha) * s1 + alpha * s2
        
        aligned_wheel.append([v_time] + aligned_state.tolist())
    return visual_data, aligned_wheel

# 扩展卡尔曼滤波器 (EKF) 的实现
def ekf_fusion(visual_data, wheel_data):
    state = np.array([0.0, 0.0, 0.0])  # 初始状态向量 [x, y, yaw]
    P = np.eye(3) * 1e-3  # 初始协方差矩阵
    Q = np.diag([0.1, 0.1, 0.01])  # 过程噪声
    R_visual = np.diag([0.5, 0.5, 0.1])  # 视觉测量噪声
    R_wheel = np.diag([0.2, 0.2, 0.05])  # 轮速测量噪声

    def predict(F, Q, state, P):
        state = F @ state
        P = F @ P @ F.T + Q
        return state, P

    def update(H, R, z, state, P):
        y = z - H @ state  # 残差
        S = H @ P @ H.T + R  # 残差协方差
        K = P @ H.T @ np.linalg.inv(S)  # 卡尔曼增益
        state = state + K @ y
        P = (np.eye(len(P)) - K @ H) @ P
        return state, P

    fused_data = []

    for v_data, w_data in zip(visual_data, wheel_data):
        z_visual = np.array([v_data[1], v_data[2], v_data[-1]])
        z_wheel = np.array([w_data[1], w_data[2], w_data[-1]])
        H_visual = np.eye(3)
        H_wheel = np.eye(3)

        dt = 0.01
        F = np.array([
            [1, 0, -dt * state[2]],
            [0, 1, dt * state[2]],
            [0, 0, 1]
        ])
        
        state, P = predict(F, Q, state, P)
        state, P = update(H_visual, R_visual, z_visual, state, P)
        state, P = update(H_wheel, R_wheel, z_wheel, state, P)

        # 将状态存储，格式为 [timestamp, x, y, z, qx, qy, qz, qw]
        timestamp = v_data[0]
        x, y, yaw = state
        qx, qy, qz, qw = 0, 0, np.sin(yaw / 2), np.cos(yaw / 2)
        fused_data.append([timestamp, x, y, 0, qx, qy, qz, qw])

    return fused_data

# 数据读取与预处理
wheel_data = pd.read_csv(
    "/home/parking/SLAM/111/5/odometry.txt", 
    sep=" ", 
    header=None, 
    names=["timestamp", "x", "y", "z", "qx", "qy", "qz", "qw"]
)

wheel_data_list = wheel_data.values.tolist()
for row in wheel_data_list:
    qx, qy, qz, qw = row[-4:]
    yaw = quaternion_to_yaw(qx, qy, qz, qw)
    row[-4:] = [yaw]

visual_data = pd.read_csv(
    "/home/parking/SLAM/output/5/frontend.txt", 
    sep=" ", 
    header=None, 
    names=["timestamp", "x", "y", "z", "qx", "qy", "qz", "qw"]
)

visual_data_list = visual_data.values.tolist()
for row in visual_data_list:
    qx, qy, qz, qw = row[-4:]
    yaw = quaternion_to_yaw(qx, qy, qz, qw)
    row[-4:] = [-yaw]

# 时间对齐与数据融合
aligned_visual_data, aligned_wheel_data = align_data_by_interpolation(visual_data_list, wheel_data_list)
fused_data = ekf_fusion(aligned_visual_data, aligned_wheel_data)

# 保存到TUM格式的文件中
output_path = "/home/parking/SLAM/fused_data.txt"
with open(output_path, "w") as f:
    for data in fused_data:
        line = " ".join(map(str, data))
        f.write(line + "\n")

print(f"Fused data saved to {output_path}")
