import numpy as np

def calculate_vehicle_pose(x1, y1, yaw1, x2, y2, yaw2):
    """
    计算车辆在 t 时刻的位姿，假设车辆在 0 时刻的位姿为 (0, 0, 0)。
    车位在0时刻的位姿为 (x1, y1, yaw1)，在 t 时刻的位姿为 (x2, y2, yaw2)。
    
    参数:
    x1, y1, yaw1 -- 0 时刻车位在车辆坐标系下的位姿 (位置和朝向)
    x2, y2, yaw2 -- t 时刻车位在车辆坐标系下的位姿 (位置和朝向)

    返回:
    vehicle_x, vehicle_y, vehicle_yaw -- 车辆在 t 时刻的位姿 (位置和朝向)
    """
    # 车位在 0 时刻的位姿 (x1, y1, yaw1)，车辆坐标系下
    # 车位在 t 时刻的位姿 (x2, y2, yaw2)，车辆坐标系下

    # 假设车辆的位姿在0时刻为 (0, 0, 0)
    # 我们需要将车位在 t 时刻的位姿转换为 0 时刻车辆坐标系下

    # 计算车位在车辆坐标系下的相对位置变化
    delta_x = x2 - x1
    delta_y = y2 - y1
    delta_yaw = yaw2 - yaw1
    
    # 旋转矩阵，旋转角度为车位在 0 时刻的朝向 yaw1
    rotation_matrix = np.array([
        [np.cos(yaw1), -np.sin(yaw1)],
        [np.sin(yaw1), np.cos(yaw1)]
    ])
    
    # 计算车辆在 t 时刻的位置
    vehicle_x = rotation_matrix[0, 0] * delta_x + rotation_matrix[0, 1] * delta_y
    vehicle_y = rotation_matrix[1, 0] * delta_x + rotation_matrix[1, 1] * delta_y
    
    # 车辆的朝向为车位在 t 时刻的朝向
    vehicle_yaw = yaw2
    
    return vehicle_x, vehicle_y, vehicle_yaw

# 示例调用：
x1, y1, yaw1 = 1.0, 2.0, np.pi / 4  # 0时刻车位的位姿 (在车辆坐标系下)
x2, y2, yaw2 = 3.0, 4.0, np.pi / 3  # t时刻车位的位姿 (在车辆坐标系下)

vehicle_x, vehicle_y, vehicle_yaw = calculate_vehicle_pose(x1, y1, yaw1, x2, y2, yaw2)

print(f"车辆在t时刻的位姿为: x = {vehicle_x:.2f}, y = {vehicle_y:.2f}, yaw = {vehicle_yaw:.2f}")
