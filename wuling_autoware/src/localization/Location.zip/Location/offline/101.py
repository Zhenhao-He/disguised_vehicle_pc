
import numpy as np
import pandas as pd
from scipy.interpolate import interp1d
import math

# 定义一个函数，将四元数转换为yaw
def quaternion_to_yaw(qx, qy, qz, qw):
    # 根据四元数计算yaw
    siny_cosp = 2 * (qw * qz + qx * qy)
    cosy_cosp = 1 - 2 * (qy**2 + qz**2)
    yaw = math.atan2(siny_cosp, cosy_cosp)
    return yaw

# 四元数球面线性插值 (SLERP)
def slerp(q1, q2, t):
    """四元数球面插值"""
    cos_half_theta = np.dot(q1, q2)
    if cos_half_theta < 0:
        q2 = -q2
        cos_half_theta = -cos_half_theta
    if cos_half_theta > 0.9995:
        return (1 - t) * q1 + t * q2
    sin_half_theta = np.sqrt(1.0 - cos_half_theta * cos_half_theta)
    theta = np.arccos(cos_half_theta)
    return (np.sin((1 - t) * theta) * q1 + np.sin(t * theta) * q2) / sin_half_theta

# 1. 读取数据
wheel_data = pd.read_csv(
    "/home/parking/SLAM/111/5/odometry.txt", 
    sep=" ", 
    header=None, 
    names=["timestamp", "x", "y", "z", "qx", "qy", "qz", "qw"]
)

# 转换为 list 格式
wheel_data_list = wheel_data.values.tolist()
# 转换四元数为yaw，并更新列表
for row in wheel_data_list:
    qx, qy, qz, qw = row[-4:]  # 提取最后四个四元数
    yaw = quaternion_to_yaw(qx, qy, qz, qw)
    row[-4:] = [yaw]  # 替换为yaw

visual_data = pd.read_csv(
    "/home/parking/SLAM/output/5/frontend.txt", 
    sep=" ", 
    header=None, 
    names=["timestamp", "x", "y", "z", "qx", "qy", "qz", "qw"]
)
# 转换为 list 格式
visual_data_list = visual_data.values.tolist()
# 转换四元数为yaw，并更新列表
for row in visual_data_list:
    qx, qy, qz, qw = row[-4:]  # 提取最后四个四元数
    yaw = quaternion_to_yaw(qx, qy, qz, qw)
    row[-4:] = [-yaw]  # 替换为yaw




















wheel_data['timestamp'] = wheel_data['timestamp'].astype(float)
visual_data['timestamp'] = visual_data['timestamp'].astype(float)

# 2. 对视觉里程计数据进行时间插值
timestamps_common = wheel_data['timestamp']  # 使用轮速数据的时间戳作为目标时间轴

interp_pos = interp1d(
    visual_data['timestamp'], 
    visual_data[['x', 'y', 'z']].values, 
    axis=0, 
    kind='linear', 
    fill_value="extrapolate"
)

interp_orient = interp1d(
    visual_data['timestamp'], 
    visual_data[['qx', 'qy', 'qz', 'qw']].values, 
    axis=0, 
    kind='linear', 
    fill_value="extrapolate"
)

visual_pos_synced = interp_pos(timestamps_common)
visual_orient_synced = interp_orient(timestamps_common)

visual_data_synced = pd.DataFrame(
    np.hstack([timestamps_common.to_numpy().reshape(-1, 1), visual_pos_synced, visual_orient_synced]),
    columns=["timestamp", "x", "y", "z", "qx", "qy", "qz", "qw"]
)

# 3. 数据融合
alpha = 0.5  # 融合权重，可调整
beta = 1 - alpha

# 融合位置信息
fused_positions = (
    alpha * wheel_data[['x', 'y', 'z']].values + 
    beta * visual_data_synced[['x', 'y', 'z']].values
)

# 融合方向信息
fused_orientations = [
    slerp(wq, vq, beta) 
    for wq, vq in zip(
        wheel_data[['qx', 'qy', 'qz', 'qw']].values, 
        visual_data_synced[['qx', 'qy', 'qz', 'qw']].values
    )
]

fused_data = pd.DataFrame(
    np.hstack([timestamps_common.to_numpy().reshape(-1, 1), fused_positions, fused_orientations]),
    columns=["timestamp", "x", "y", "z", "qx", "qy", "qz", "qw"]
)

# 4. 保存融合结果
fused_data.to_csv("/home/parking/SLAM/fused_result.txt", sep=" ", header=False, index=False)

print("融合完成，结果已保存至 /home/parking/SLAM/fused_result.txt")
