import numpy as np
from scipy.optimize import least_squares
import matplotlib.pyplot as plt

class VehicleTrajectoryOptimizer:
    def __init__(self, corners_trajectory, vehicle_trajectory_initial, global_corners):
        """
        初始化优化器。

        :param corners_trajectory: np.ndarray, 形状为 (15, 10, 2)，表示15个地标在历史10帧中车辆坐标系下的x,y坐标
        :param vehicle_trajectory_initial: np.ndarray, 形状为 (10, 3)，表示历史10帧中车辆的初始估计位姿 [x, y, yaw]
        :param global_corners: np.ndarray, 形状为 (15, 2)，表示15个地标在全局坐标系下的x,y坐标
        """
        self.corners_trajectory = corners_trajectory
        self.vehicle_trajectory_initial = vehicle_trajectory_initial
        self.global_corners = global_corners
        self.num_landmarks = global_corners.shape[0]
        self.num_frames = vehicle_trajectory_initial.shape[0]

    @staticmethod
    def normalize_angle(angle):
        """
        将角度归一化到 [-pi, pi] 范围内。

        :param angle: float 或 np.ndarray
        :return: float 或 np.ndarray
        """
        return (angle + np.pi) % (2 * np.pi) - np.pi

    def residuals_function(self, p):
        """
        计算残差向量。

        :param p: np.ndarray, 形状为 (30,) 的车辆位姿参数向量
        :return: residuals (300,)
        """
        residuals = []

        # 重塑参数向量为 (10, 3)
        vehicle_poses = p.reshape(self.num_frames, 3)

        for f in range(self.num_frames):
            x_f, y_f, yaw_f = vehicle_poses[f]

            cos_yaw = np.cos(yaw_f)
            sin_yaw = np.sin(yaw_f)

            # 旋转矩阵 R_f (2x2) 从全局坐标系到车辆坐标系
            R_f = np.array([[cos_yaw, sin_yaw],
                            [-sin_yaw, cos_yaw]])

            for l in range(self.num_landmarks):
                # 全局地标位置
                X_l, Y_l = self.global_corners[l]

                # 车辆坐标系下观测到的地标位置
                observed_lf_x, observed_lf_y = self.corners_trajectory[l, f]

                # 预测观测位置（车辆坐标系下）
                delta = np.array([X_l - x_f, Y_l - y_f])
                r_pred = R_f @ delta  # 旋转到车辆坐标系
                residual_x = r_pred[0] - observed_lf_x
                residual_y = r_pred[1] - observed_lf_y

                residuals.extend([residual_x, residual_y])

        return np.array(residuals)  # (300,)

    def jacobian_function(self, p):
        """
        计算雅可比矩阵。

        :param p: np.ndarray, 形状为 (30,) 的车辆位姿参数向量
        :return: J (300, 30)
        """
        J = np.zeros((self.num_landmarks * self.num_frames * 2, self.num_frames * 3))

        vehicle_poses = p.reshape(self.num_frames, 3)

        row = 0
        for f in range(self.num_frames):
            x_f, y_f, yaw_f = vehicle_poses[f]

            cos_yaw = np.cos(yaw_f)
            sin_yaw = np.sin(yaw_f)

            # 旋转矩阵 R_f (2x2) 从全局坐标系到车辆坐标系
            R_f = np.array([[cos_yaw, sin_yaw],
                            [-sin_yaw, cos_yaw]])

            for l in range(self.num_landmarks):
                # 全局地标位置
                X_l, Y_l = self.global_corners[l]

                # 车辆坐标系下观测到的地标位置
                observed_lf_x, observed_lf_y = self.corners_trajectory[l, f]

                # 预测观测位置（车辆坐标系下）
                delta = np.array([X_l - x_f, Y_l - y_f])

                # 雅可比矩阵的导数
                dr_dx = -R_f[:, 0]  # 对x_f的导数
                dr_dy = -R_f[:, 1]  # 对y_f的导数
                dr_dyaw = R_f @ np.array([[0, 0],
                                          [delta[0], delta[1]]])  # 对yaw_f的导数

                # 填充雅可比矩阵
                J[row, 3*f] = dr_dx[0]
                J[row, 3*f+1] = dr_dy[0]
                J[row, 3*f+2] = dr_dyaw[0]

                J[row+1, 3*f] = dr_dx[1]
                J[row+1, 3*f+1] = dr_dy[1]
                J[row+1, 3*f+2] = dr_dyaw[1]

                row += 2

        return J  # (300, 30)

    def optimize_trajectory(self, use_jacobian=True, max_iters=100, tol=1e-6):
        """
        使用Levenberg-Marquardt方法优化车辆轨迹。

        :param use_jacobian: bool, 是否使用雅可比矩阵
        :param max_iters: int, 最大迭代次数
        :param tol: float, 收敛容差
        :return: np.ndarray, 形状为 (10, 3)，优化后的车辆轨迹
        """
        # 初始化参数向量 p (30,)
        p_initial = self.vehicle_trajectory_initial.flatten()

        if use_jacobian:
            # 使用自定义雅可比矩阵
            result = least_squares(
                self.residuals_function,
                p_initial,
                jac=self.jacobian_function,
                method='lm',
                max_nfev=max_iters,
                ftol=tol,
                xtol=tol,
                gtol=tol
            )
        else:
            # 使用数值雅可比矩阵
            result = least_squares(
                self.residuals_function,
                p_initial,
                method='lm',
                max_nfev=max_iters,
                ftol=tol,
                xtol=tol,
                gtol=tol
            )

        # 检查优化是否成功
        if not result.success:
            print(f"优化未成功: {result.message}")
        else:
            print("优化成功。")

        # 重塑参数向量为 (10, 3)
        vehicle_trajectory_optimized = result.x.reshape(self.num_frames, 3)

        # 角度归一化
        vehicle_trajectory_optimized[:, 2] = self.normalize_angle(vehicle_trajectory_optimized[:, 2])

        return vehicle_trajectory_optimized

# 示例用法
if __name__ == "__main__":
    # 生成模拟数据
    np.random.seed(42)  # 为可重复性设置随机种子

    num_landmarks = 15
    num_frames = 10

    # 全局地标位置 (15, 2)
    global_corners = np.random.uniform(-10, 10, (num_landmarks, 2))

    # 真实车辆轨迹 (10, 3): [x, y, yaw]
    true_vehicle_trajectory = np.array([[i, 0.5*i, np.deg2rad(5*i)] for i in range(num_frames)])

    # 生成观测数据 (15, 10, 2)
    corners_trajectory = np.zeros((num_landmarks, num_frames, 2))
    noise_std = 0.1  # 观测噪声标准差

    for f in range(num_frames):
        x_f, y_f, yaw_f = true_vehicle_trajectory[f]
        cos_yaw = np.cos(yaw_f)
        sin_yaw = np.sin(yaw_f)
        R_f = np.array([[cos_yaw, sin_yaw],
                        [-sin_yaw, cos_yaw]])

        for l in range(num_landmarks):
            delta = global_corners[l] - np.array([x_f, y_f])
            obs = R_f @ delta + np.random.normal(0, noise_std, 2)
            corners_trajectory[l, f] = obs

    # 初始车辆轨迹估计 (10, 3)
    vehicle_trajectory_initial = np.zeros((num_frames, 3))  # 假设起始于原点，yaw为0

    # 初始化优化器
    optimizer = VehicleTrajectoryOptimizer(corners_trajectory, vehicle_trajectory_initial, global_corners)

    # 执行优化
    optimized_trajectory = optimizer.optimize_trajectory(use_jacobian=True)

    # 打印结果
    print("\n优化后的车辆轨迹：")
    print(optimized_trajectory)

    print("\n真实车辆轨迹：")
    print(true_vehicle_trajectory)

    # 可视化优化结果
    plt.figure(figsize=(10, 8))
    plt.scatter(global_corners[:, 0], global_corners[:, 1], marker='^', color='red', label='地标')
    plt.plot(true_vehicle_trajectory[:, 0], true_vehicle_trajectory[:, 1], 'g-', label='真实轨迹')
    plt.plot(optimized_trajectory[:, 0], optimized_trajectory[:, 1], 'b--', label='优化轨迹')
    plt.xlabel('X')
    plt.ylabel('Y')
    plt.title('车辆轨迹优化')
    plt.legend()
    plt.axis('equal')
    plt.grid(True)
    plt.show()
