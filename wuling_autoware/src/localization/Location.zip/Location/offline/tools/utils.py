import numpy as np

def calculate_yaw(R):
    """
    根据二维旋转矩阵计算偏航角（yaw）
    
    参数:
        R (numpy.ndarray): 2x2 的旋转矩阵
    
    返回:
        float: 偏航角，单位为弧度
    """
    assert R.shape == (2, 2), "旋转矩阵必须是 2x2 矩阵"
    theta = np.arctan2(R[1, 0], R[0, 0])  # atan2(sin(theta), cos(theta))
    return theta

# 示例旋转矩阵
R = np.array([
    [0.99822865, 0.0594943],  # cos(30°), -sin(30°)
    [-0.0594943, 0.99822865]    # sin(30°), cos(30°)
])

yaw = calculate_yaw(R)
print(f"Yaw (radians): {yaw}")
print(f"Yaw (degrees): {np.degrees(yaw)}")
