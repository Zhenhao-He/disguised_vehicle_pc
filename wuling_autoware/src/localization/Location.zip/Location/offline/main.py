# coding:utf-8
# create by zhangyucheng 2024/11/15 in whut


import numpy as np
import json
import os
import re
from scipy.spatial.transform import Rotation as R
from collections import deque

from scipy.optimize import minimize
from scipy.optimize import least_squares

from draw import Draw
from measure import Measure
from slidewindow_graph import Slidewindow_graph
from save_trajectories import *


def load_tracked_data(file_path):
    """加载带有跟踪 ID 的点数据"""
    with open(file_path, 'r', encoding='utf-8') as file:
        data = json.load(file)
    return data

def extract_timestamp(filename):
    """从文件名中提取时间戳，并转换为浮点格式"""
    timestamp_str = filename.split('_')[1].split('.')[0]
    timestamp = float(timestamp_str[:10] + '.' + timestamp_str[10:])
    return timestamp

def error_function(pose, trajectory_array2):
    x, y, theta = pose  # 初始猜测的位姿
    errors = []
    
    # 遍历每个地标
    for i in range(15):
        landmark = trajectory_array2[i, :, :]  # 地标的坐标（在自车坐标系下）
        
        # 假设每个地标的观察到的坐标
        observed_x, observed_y = landmark[0, 0], landmark[0, 1]
        
        # 理论坐标（通过位姿变换计算）
        predicted_x = x + np.cos(theta) * landmark[0, 0] - np.sin(theta) * landmark[0, 1]
        predicted_y = y + np.sin(theta) * landmark[0, 0] + np.cos(theta) * landmark[0, 1]
        
        # 计算误差
        error = np.sqrt((observed_x - predicted_x) ** 2 + (observed_y - predicted_y) ** 2)
        errors.append(error)
    
    return np.array(errors)


init_pose = np.array([[0], [0], [0]])
estimate_init_pose = np.array([[0], [0], [0]])

slidewindow_graph = Slidewindow_graph()
draw = Draw(slidewindow_graph)

# 循环计数
n = 0
sum = 5000

input_json_path = './data/tracked_coordinates_5.json'
data = load_tracked_data(input_json_path)

# # 保存结果的字典
# new_data = {}
# offset = 42070.433
# for key, value in data.items():
#     # 提取数字部分
#     number_str = key.split('_')[1].split('.')[0]  # 获取 "1730927662670"
#     number = float(number_str) / 1000  # 将其转换为浮点数，假定时间戳为毫秒级
#     # 计算新数字
#     new_number = number - offset
#     new_number = new_number * 1000
#     # 格式化数字并生成新键名
#     new_number_formatted = f"img_{int(new_number):,}".replace(",", "") + ".png"
#     # 将新的键值对保存到字典
#     new_data[new_number_formatted] = value
# # 保存字典到 JSON 文件
# output_file = "new_data.json"
# with open(output_file, 'w', encoding='utf-8') as f:
#     json.dump(new_data, f, indent=4, ensure_ascii=False)

odometry = []
history_points = deque(maxlen=10)

while n != sum:

    measure = Measure()
    measure._pose_id = n
    n_th_key = list(data.keys())[n]  # 获取第 n 个键
    for i in range(len(data[n_th_key])):
        measure._data[1].append(-(data[n_th_key][i][1] - 575)*0.0094)
        measure._data[0].append(-(data[n_th_key][i][2] - 810)*0.0094)
        measure._data[2].append(data[n_th_key][i][0])

    history_points.append(data[n_th_key])
    trajectory_array_pre = np.zeros((15, 10, 3), dtype=float)
    if n>9:
        all_id = []
        # 遍历每一帧的智能体数据
        for frame_data in history_points:
            for agent in frame_data:
                if agent[0] not in all_id:
                    all_id.append(agent[0])

        for id in range(len(all_id)):
            for frame_id, frame_data in enumerate(history_points):
                for agent_id, agent in enumerate(frame_data):
                    if agent[0] == all_id[id]:
                        trajectory_array_pre[id][frame_id][0] = agent[0]
                        trajectory_array_pre[id][frame_id][1] = -(agent[2] - 810)*0.0094
                        trajectory_array_pre[id][frame_id][2] = -(agent[1] - 575)*0.0094
    measure.trajectory_array = trajectory_array_pre[:,:,1:3]


    # if n>9:
    #     initial_pose = [0, 0, 0]
    #     # trajectory_vehicle = np.zeros((10, 2))  # 10时间步，自车位置 (x, y)
    #     result = least_squares(error_function, initial_pose, args=(measure.trajectory_array,))
    #     # 输出优化后的自车位姿
    #     optimized_pose = result.x
    #     print(f"Optimized pose: x={optimized_pose[0]}, y={optimized_pose[1]}, theta={optimized_pose[2]}")

    if n == 0:
        slidewindow_graph.Initialize(estimate_init_pose, measure)
    else:
        slidewindow_graph.Update(measure,n) 

    draw.Show_result()

    frontend_txt_path = 'output/image/frontend.txt'
    backend_txt_path = 'output/image/backend.txt'

    save_frontend_to_txt(slidewindow_graph, data, n, odometry, frontend_txt_path)
    save_backend_to_txt(slidewindow_graph, data, n, odometry, backend_txt_path)

    # output_txt_path_offline = 'output/trajectory.txt'
    # if n == 203:
    #     save_trajectory_to_txt(slidewindow_graph, data, output_txt_path_offline)


    print(n)
    # print(f"车位右上角点的位置为: {slidewindow_graph._mappoints_DB[1]._pose[0][0]:.2f}, {slidewindow_graph._mappoints_DB[1]._pose[1][0]:.2f}")



    n = n + 1

