import rclpy
from rclpy.node import Node
from geometry_msgs.msg import PoseWithCovarianceStamped
from geometry_msgs.msg import PoseStamped
import math
from datetime import datetime
from builtin_interfaces.msg import Time




class VelocityLogger(Node):
    def __init__(self):
        super().__init__('velocity_logger')
        self.subscription = self.create_subscription(
            PoseWithCovarianceStamped,
            '~/input/UTM',
            self.listener_callback,
            10)
        
        print("start !!!!!!")
        # self.subscription  # 防止未使用的变量警告
        # 创建Publisher来发布PoseStamped消息
        self.pose_publisher = self.create_publisher(PoseStamped, '~/output/position', 10)
        self.start_flag = 0
        self.initial_x = 0.0
        self.initial_y = 0.0
        self.initial_yaw = 0.0
        self.pi_value = math.pi

        self.robot_status = {
            'position_x_': 0.0,  # 初始位置
            'position_y_': 0.0,
            'position_yaw_': 0.0
        }

    def listener_callback(self, msg):
        timestamp = msg.header.stamp.sec + msg.header.stamp.nanosec * 1e-9
        x = msg.pose.pose.position.x
        y = msg.pose.pose.position.y
        q = msg.pose.pose.orientation
        
        yaw = math.atan2(2.0 * (q.w * q.z + q.x * q.y), 1.0 - 2.0 * (q.y * q.y + q.z * q.z))

        if self.start_flag < 10:
            self.initial_x = x
            self.initial_y = y
            self.initial_yaw = yaw #+88.45* 3.14159265358979323846 / 180.0
            self.start_flag += 1

        else:
            x_cor = x - self.initial_x
            y_cor = y - self.initial_y
            yaw_cor = yaw - self.initial_yaw

            self.get_logger().info(f'Position: x={x_cor:.3f}, y={y_cor:.3f}, yaw_cor={math.degrees(yaw_cor):.2f}°')
            
            
            self.get_logger().info(f'absolate Position: x={x:.3f}, y={y:.3f}, yaw={math.degrees(yaw):.2f}°')
            
            # new_x = x_cor * math.cos(self.initial_yaw) + y_cor * math.sin(self.initial_yaw)
            # new_y = -x_cor * math.sin(self.initial_yaw) + y_cor * math.cos(self.initial_yaw)

            new_x = x_cor * math.cos(yaw) + y_cor * math.sin(yaw)
            new_y = -x_cor * math.sin(yaw) + y_cor * math.cos(yaw)

            print("jiaodu!!!!!!!!!!!!!!!!!!!",yaw_cor)

            # 更新机器人位置
            self.robot_status['position_x_'] = new_y
            self.robot_status['position_y_'] = new_x
            self.robot_status['position_yaw_'] = yaw_cor

            if self.robot_status['position_yaw_']>self.pi_value:
                self.robot_status['position_yaw_']=self.robot_status['position_yaw_']-2*self.pi_value
            if self.robot_status['position_yaw_']<-self.pi_value:
                self.robot_status['position_yaw_']=self.robot_status['position_yaw_']+2*self.pi_value

            self.publish_pose(self.robot_status['position_x_'], self.robot_status['position_y_'], self.robot_status['position_yaw_'], timestamp)
   

    @staticmethod
    def euler_to_quaternion(yaw):
        """
        将欧拉角（yaw）转换为四元数。
        假设只有绕z轴的旋转（2D平面旋转）。
        """
        qw = math.cos(yaw / 2.0)
        qx = 0.0
        qy = 0.0
        qz = math.sin(yaw / 2.0)
        return qx, qy, qz, qw

    def publish_pose(self, x, y, yaw, timestamp):
        """
        发布机器人的位姿信息（Position + Quaternion）。
        """
        # 创建 PoseStamped 消息
        pose_msg = PoseStamped()

        # 创建时间戳消息
        time_msg = Time()
        time_msg.sec = int(timestamp)  # 时间戳的秒部分
        time_msg.nanosec = int((timestamp - int(timestamp)) * 1e9)  # 时间戳的小数部分转纳秒

        # 设置时间戳
        pose_msg.header.stamp = time_msg

        pose_msg.header.frame_id = 'map'  # 可以根据需要修改坐标系

        # 设置位置信息
        pose_msg.pose.position.x = x
        pose_msg.pose.position.y = y
        pose_msg.pose.position.z = 0.0  # 假设机器人只在平面上运动

        # 设置四元数表示的朝向
        qx, qy, qz, qw = self.euler_to_quaternion(yaw)
        pose_msg.pose.orientation.x = qx
        pose_msg.pose.orientation.y = qy
        pose_msg.pose.orientation.z = qz
        pose_msg.pose.orientation.w = qw

        # 发布消息
        self.pose_publisher.publish(pose_msg)




def main(args=None):
    rclpy.init(args=args)
    velocity_logger = VelocityLogger()

    velocity_logger.get_logger().info("Velocity logger node with odometry computation and pose publishing has started.")
    
    try:
        rclpy.spin(velocity_logger)
    except KeyboardInterrupt:
        pass
    finally:
        velocity_logger.destroy_node()
        rclpy.shutdown()

if __name__ == '__main__':
    main()

